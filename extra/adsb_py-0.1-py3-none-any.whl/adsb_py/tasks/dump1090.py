from PyQt5.QtCore import (QObject, QProcess, QThread, pyqtSignal, pyqtSlot)
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QTextEdit,
                             QPushButton)

import sys
import time
import logging
import os.path


class Worker(QObject):

    sendOutput = pyqtSignal(str)

    def __init__(self):
        super(Worker, self).__init__()
        self.process = QProcess()
        self.exec_ = os.path.join(os.path.dirname(__file__),
                                  "..", "tools", sys.platform, "dump1090")
        logging.info("dump1090 path: {}".format(self.exec_))
        self.path = "{} --net".format(self.exec_)
        self.start()

    def __del__(self):
        self.stop()

    def start(self):
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(self.readStdOutput)
        self.process.start(self.path)

    def stop(self):
        self.process.kill()

    @pyqtSlot()
    def readStdOutput(self):
        output = self.process.readAllStandardOutput()
        self.sendOutput.emit(output.data().decode())


class Dump1090Process():

    def __init__(self, parent=None):
        super(Dump1090Process, self).__init__(parent)
        self.d1090_output = QTextEdit()
        self.d1090_output.setMaximumHeight(400)
        self.d1090_thread = QThread()

    def setupConnections(self):
        self.d1090_worker = Worker()
        self.d1090_thread.finished.connect(self.d1090_worker.stop)
        self.d1090_worker.sendOutput.connect(self.showOutput)
        self.d1090_worker.moveToThread(self.d1090_thread)
        self.d1090_thread.start()

    def __del__(self):
        self.d1090_thread.quit()
        while self.d1090_thread.isRunning():
            time.sleep(1)

    @pyqtSlot(str)
    def showOutput(self, output):
        self.d1090_output.append(output)


class Test_Layout(Dump1090Process, QWidget):

    def __init__(self):
        super(Test_Layout, self).__init__()
        layout = QVBoxLayout()

        self.start_button = QPushButton("Start")
        self.start_button.clicked.connect(self.setupConnections)

        self.stop_button = QPushButton("Stop")
        self.stop_button.clicked.connect(lambda: self.d1090_worker.stop())

        self.setupConnections()
        layout.addWidget(self.d1090_output)
        layout.addWidget(self.start_button)
        layout.addWidget(self.stop_button)
        self.setLayout(layout)
        self.show()


def main():
    app = QApplication(sys.argv)
    w = Test_Layout()
    w.show()

    return app.exec_()


if __name__ == '__main__':
    main()
