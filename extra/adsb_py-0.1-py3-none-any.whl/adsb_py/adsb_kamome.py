import os
import re
import sys
import pathlib

import adsb_py


def detect_environment():
    if hasattr(sys, 'real_prefix'):  # means no virtualenv
        return "source {}/bin/activate".format(sys.exec_prefix)
    # TODO Linux Anaconda without environment
    for e in sys.path:
        match = re.match("(.*)/envs/(.*)/lib/python3.\d", e)
        if match:
            prefix = 'export PATH="{}:$PATH"\n'.format(match.group(1))
            if sys.platform == 'linux':
                prefix += 'export LD_LIBRARY_PATH="{}:$LD_LIBRARY_PATH"\n'
                prefix = prefix.format(match.group(0)[:-9])
            return prefix + "source {}/bin/activate {}".format(
                match.group(1), match.group(2))


linux_desktop = """#!/usr/bin/env xdg-open

[Desktop Entry]
Version=1.0
Name=kamome
Comment=Tracking aircraft using ADS-B data
Exec={script_path}
Icon={icon_path}
Terminal=false
Type=Application
Categories=Utility;
"""

linux_script = """#!/usr/bin/env bash
{}
python -c "import adsb_py.adsb_gui as asg; asg.main()"
"""


def make_app_linux():
    icon_path = adsb_py.__path__[0] + "/data/travel-grey.svg"
    script_path = os.path.expanduser("~/.local/bin/kamome.sh")

    with open(script_path, 'w') as fh:
        fh.write(linux_script.format(detect_environment()))
        mode = os.fstat(fh.fileno()).st_mode
        mode |= 0o111
        os.fchmod(fh.fileno(), mode & 0o7777)

    with open('kamome.desktop', 'w') as fh:
        fh.write(linux_desktop.format(icon_path=icon_path,
                                      script_path=script_path))
        mode = os.fstat(fh.fileno()).st_mode
        mode |= 0o111
        os.fchmod(fh.fileno(), mode & 0o7777)


darwin_plist = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple Computer//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>LSBackgroundOnly</key>
    <string>0</string>
    <key>CFBundleDevelopmentRegion</key>
    <string>English</string>
    <key>CFBundleName</key>
    <string>kamome</string>
    <key>CFBundleExecutable</key>
    <string>MacOS/main.sh</string>
    <key>CFBundleGetInfoString</key>
    <string>kamome, plot and record ADS-B signals</string>
    <key>CFBundleIconFile</key>
    <string>travel.icns</string>
    <key>CFBundleIdentifier</key>
    <string>org.xoolive.kamome</string>
    <key>CFBundleInfoDictionaryVersion</key>
    <string>6.0</string>
    <key>CFBundleDisplayName</key>
    <string>kamome</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
    <key>NSHumanReadableCopyright</key>
    <string>Copyright 2017, Xavier Olive</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
"""


darwin_script = """#! /bin/bash

DIR=${0%/*}
${DIR}/kamome -c "import adsb_py.adsb_gui as asg; asg.main()"
"""


def make_app_darwin():
    pythonapp = sys.exec_prefix

    if not hasattr(sys, 'real_prefix'):  # means no virtualenv
        pythonapp = os.path.join(pythonapp, "Resources")

    if 'conda' in sys.version or 'Continuum' in sys.version:
        pythonapp = sys.executable
    else:
        pythonapp = os.path.join(pythonapp,
                                 "Python.app", "Contents", "MacOS", "Python")

    os.makedirs(os.path.join("kamome.app", "Contents", "MacOS"))
    os.makedirs(os.path.join("kamome.app", "Contents", "Resources"))

    if 'conda' in sys.version or 'Continuum' in sys.version:
        pass
    else:
        os.link(pythonapp,
                os.path.join("kamome.app", "Contents", "MacOS", "kamome"))

    with open(os.path.join("kamome.app", "Contents",
                           "Info.plist"), 'w') as fh:
        fh.write(darwin_plist)

    with open(os.path.join("kamome.app", "Contents", "MacOS",
                           "main.sh"), 'w') as fh:
        if 'conda' in sys.version or 'Continuum' in sys.version:
            fh.write(linux_script.format(detect_environment()))
        else:
            fh.write(darwin_script)
        mode = os.fstat(fh.fileno()).st_mode
        mode |= 0o111
        os.fchmod(fh.fileno(), mode & 0o7777)

    icon_path = adsb_py.__path__[0] + "/data/travel.icns"

    os.link(icon_path,
            os.path.join("kamome.app", "Contents", "Resources", "travel.icns"))



windows_batch = """"{}" -x %0 %*    &goto :eof
import adsb_py.adsb_gui as asg;
asg.main()
"""


def make_app_windows():

    with open("kamome.bat", 'w') as fh:
        fh.write(windows_batch.format(sys.executable))

    try:
        from win32com.client import Dispatch
    except ImportError:
        import subprocess
        subprocess.call("conda install pywin32")
        print("Missing package installed, relaunch script")
        return

    path = "kamome.lnk"
    target = str(pathlib.Path("kamome.bat").absolute())
    icon_path = adsb_py.__path__[0] + "/data/travel.ico"

    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(path)
    shortcut.TargetPath = target
    shortcut.IconLocation = icon_path
    shortcut.save()


# TODO linux : librtlsdr-dev


def main():
    fname = {'linux': make_app_linux,
             'darwin': make_app_darwin,
             'win32': make_app_windows}
    fname[sys.platform]()

if __name__ == '__main__':
    main()
