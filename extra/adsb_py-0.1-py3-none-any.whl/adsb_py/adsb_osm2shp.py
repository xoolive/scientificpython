import xml.etree.ElementTree as ET

import fiona
from shapely.geometry import LineString, mapping


def osm2shp(input_file, output_file, plot=False):
    if plot:
        import matplotlib.pyplot as plt
        from geotools.projection import sph2lcc
        fig = plt.figure()
        ax = fig.gca()

    tree = ET.parse(input_file)
    root = tree.getroot()

    # Store nodes with IDs
    nodes = {}
    for p in root.iter("node"):
        nodes[p.attrib['id']] = float(p.attrib['lon']), float(p.attrib['lat'])

    # different types of 'aeroway'
    types = set(x.attrib['v'] for p in root.iter("way")
                for x in p.findall('tag')
                if x.attrib['k'] == "aeroway")
    print(types)

    crs = {'no_defs': True, 'ellps': 'WGS84',
           'datum': 'WGS84', 'proj': 'longlat'}
    schema = {'geometry': 'LineString',
              'properties': {'NAME': 'str', 'TYPE': 'str'}}

    with fiona.open(output_file, 'w', driver="ESRI Shapefile",
                    crs=crs, schema=schema, encoding='utf-8') as output:

        for p in root.iter("way"):
            for x in p.findall("tag"):
                if x.attrib["k"] == "aeroway":
                    type_aeroway = x.attrib['v']
                    name = [x.attrib['v'] for x in p.findall('tag')
                            if x.attrib['k'] == 'name']

                    name = name[0] if len(name) > 0 else ''
                    points = []
                    for n in p.findall("nd"):
                        points.append(nodes[n.attrib['ref']])

                    if plot:
                        plt.plot(*(sph2lcc([p[1] for p in points],
                                           [p[0] for p in points])),
                                 color="#aaaaaa")

                    output.write({'geometry': mapping(LineString(points)),
                                  'properties': {'NAME': name,
                                                 "TYPE": type_aeroway}})

    if plot:
        fig.set_size_inches(10, 7)
        ax.axis('scaled')
        plt.show()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(
        description="Transform OpenStreetMap files into shapefiles.")

    parser.add_argument("input_file", help="path to the OSM file")
    parser.add_argument("output_file", help="path to the SHP file")

    parser.add_argument("-p", dest="plot", action="store_true",
                        help="plot the LineStrings that have been written")

    args = parser.parse_args()

    osm2shp(args.input_file, args.output_file, args.plot)
