import re
import logging
from datetime import datetime
from collections import namedtuple
import urllib.request as urlrequest

from zeep import Client
from requests import Session
from requests.auth import HTTPBasicAuth
from zeep.transports import Transport


field = namedtuple('field', 'callsign airline origin destination date')


class Planefinder(object):

    pf_url = "https://planefinder.net/"

    user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:46.0)"
    user_agent += " Gecko/20100101 Firefox/46.0"
    headers = {'User-Agent': user_agent}

    def __init__(self, *args, **kwargs):
        pass

    def get_info(self, callsign):
        msg = 'Getting info about callsign {} from planefinder.net'
        logging.debug(msg.format(callsign))
        # just in case, some weird callsigns out there
        callsign = str(callsign)
        url = urlrequest.urljoin(self.pf_url,
                                 "/data/flight/{}".format(callsign))
        req = urlrequest.Request(url, None, self.headers)
        html = urlrequest.urlopen(req).read()
        raw = html.decode()
        regex = '\>[\w\s]+ \((\w+)\) &mdash; [\w\s]+ \((\w+)\)'
        m = next(re.finditer(regex, raw), None)

        if m is None:
            msg = 'Failed to retrieve info from {}'
            logging.warn(msg.format(url))
            return None

        return field(callsign, None, m.group(1), m.group(2),
                     datetime.utcnow().date())


class FlightXML3(object):

    client = None

    def __init__(self, username, apiKey):
        wsdl = 'https://flightxml.flightaware.com/soap/FlightXML3/wsdl'
        session = Session()
        session.auth = HTTPBasicAuth(username, apiKey)
        self.client = Client(wsdl, transport=Transport(session=session))

    def get_info(self, callsign):
        msg = 'Getting info about callsign {} from FlightXML3'
        logging.debug(msg.format(callsign))
        callsign = str(callsign)
        try:
            rep = self.client.service.FlightInfoStatus(callsign, howMany=1)
            flight = next(iter(rep['flights']))
            return field(callsign, flight['airline'],
                         flight['origin']['code'],
                         flight['destination']['code'],
                         datetime.utcnow().date())
        except:
            msg = 'Failed to retrieve info from FlightXML3 for {}'
            logging.warn(msg.format(callsign))
            return None

