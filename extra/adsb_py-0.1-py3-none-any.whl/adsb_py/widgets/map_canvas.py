from PyQt5.QtWidgets import QSizePolicy, QGestureEvent
from PyQt5.QtCore import Qt

import os
import re
import sys
import pathlib
import logging

from shutil import copy

from matplotlib import cm
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg

from cartopy.crs import PlateCarree
from cartopy.feature import NaturalEarthFeature

import cartopy.io.shapereader as shpreader

from adsb_py.core.projections import projections


class MapCanvas(FigureCanvasQTAgg):

    def __init__(self, config, parent=None, width=5, height=4, dpi=100):

        logging.info('Initialize MapCanvas')

        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.config = config
        self.main = parent

        FigureCanvasQTAgg.__init__(self, self.fig)
        self.setParent(parent)
        FigureCanvasQTAgg.setSizePolicy(self, QSizePolicy.Expanding,
                                        QSizePolicy.Expanding)
        FigureCanvasQTAgg.updateGeometry(self)
        self.grabGesture(Qt.PinchGesture)

        self.shapes = []
        self.loaded = []

        projs = self.config.get('maps', 'settings', fallback='default')
        self.settings = 'default'
        self.switch_settings([s.strip() for s in projs.split(',')][0])
        self.print_callsign = self.config.getboolean(
            'global', 'logs', fallback=False)

        self.cmap = cm.viridis

    def init_lims(self):

        self.axes = None
        self.lims = self.config.get(self.settings, 'lims', fallback=None)
        try:
            if self.lims is not None:
                self.lims = tuple(float(f) for f in self.lims.split(','))
                assert len(self.lims) == 4
        except Exception as e:
            logging.exception(e)
            self.lims = None

    def autoload_shapefiles(self):
        logging.info('Automatic loading of shapefiles')

        airports = self.config.get(self.settings, 'airports', fallback=None)
        if airports is None:
            return

        airports = [s.strip() for s in airports.split(',')]
        logging.debug("{}".format(airports))
        shapedir = os.path.join(self.main.confdir, "shapefiles")
        for filename in os.listdir(shapedir):
            if filename in self.loaded:
                continue
            match = re.match('(.*)\.shp', filename)
            if match and match.group(1) in airports:
                self.loaded.append(filename)
                self.loadShapefile(os.path.join(shapedir, filename), False)

    def switch_settings(self, settings):
        logging.info('Switch to settings {}'.format(settings))
        old_settings = self.settings
        self.settings = settings

        projection_name = self.config.get(self.settings, 'projection',
                                          fallback=None)

        if projection_name is None:
            self.settings = old_settings
            return

        self.projection = projections[projection_name]
        self.autoload_shapefiles()
        self.init_lims()
        self.create_map()

    def switch_callsign(self, entry):
        self.print_callsign = entry

    def loadShapefile(self, filename, recreate=True):
        logging.info('Loading shapefile {}'.format(filename))
        self.shapes.append(shpreader.Reader(filename))
        if recreate:
            self.create_map()

    def saveShapes(self):
        dst_dir = os.path.join(self.main.confdir, "shapefiles")
        for shape in self.shapes:
            p = pathlib.Path(shape._reader.shp.name)
            src_dir = str(p.absolute().parent)
            for x in os.listdir(src_dir):
                if str(p.name)[:-len(p.suffix)] in x:
                    copy(os.path.join(src_dir, x), dst_dir)

    def event(self, event):
        if isinstance(event, QGestureEvent):
            self.gestureEvent(event)
        return super().event(event)

    def background_map(self):

        info = 'Background map for setting {}'
        logging.info(info.format(self.settings))
        self.axes = self.fig.add_subplot(111, projection=self.projection)

        precision = self.config.get(self.settings, 'precision', fallback='50m')

        # -- Rivers --

        rivers = NaturalEarthFeature(
            category='physical',
            name='rivers_lake_centerlines',
            scale='10m',
            edgecolor='#226666',
            facecolor='none',
            alpha=.5
        )

        if self.config.getboolean(self.settings, 'rivers',
                                  fallback=False):
            self.axes.add_feature(rivers)

        # -- Administrative divisions --

        admin0_details = shpreader.natural_earth(
            resolution='10m', category="cultural",
            name="admin_0_boundary_lines_map_units")

        countries = self.config.get(self.settings,
                                    'admin-unit', fallback="")

        if countries != "":
            countries = set(country.strip()
                            for country in countries.split(','))

            country = (r.geometry
                       for r in shpreader.Reader(admin0_details).records()
                       if r.attributes['adm0_name'] in countries)

            self.axes.add_geometries(country,
                                     PlateCarree(),
                                     edgecolor="#676360",
                                     facecolor='none',
                                     linewidth=.5,
                                     alpha=.7)

        admin1_file = shpreader.natural_earth(
            resolution='10m', category='cultural',
            name='admin_1_states_provinces_lines')

        countries = self.config.get(self.settings, 'admin', fallback="")
        more = self.config.get(self.settings, 'admin-more', fallback="")

        if countries + more != "":
            countries = countries + ", " + more
            countries = set(country.strip()
                            for country in countries.split(','))
            more = set(country.strip()
                       for country in more.split(','))
            pattern = (lambda country: '.*' if country in more
                       else '.*(statistical|region).*')

            country = (r.geometry
                       for r in shpreader.Reader(admin1_file).records()
                       if r.attributes['adm0_name'] in countries and
                       re.match(pattern(r.attributes['adm0_name']),
                                r.attributes['featurecla']))

            self.axes.add_geometries(country,
                                     PlateCarree(),
                                     edgecolor="#676360",
                                     facecolor='none',
                                     linewidth=.5,
                                     alpha=.7)

        # -- Countries --

        countries = NaturalEarthFeature(
            category='cultural',
            name='admin_0_countries',
            scale=precision,
            edgecolor='#524c50',
            facecolor='none',
            alpha=.5)

        self.axes.add_feature(countries)

        # -- Coastlines --

        self.axes.coastlines(precision, color="#226666")

        self.axes.axis('off')
        self.fig.patch.set_visible(False)
        self.fig.tight_layout()

    def create_map(self):

        if self.lims is not None and self.axes is not None:
            self.lims = self.axes.axis()

        self.fig.clear()
        self.background_map()

        for shape in self.shapes:
            self.axes.add_geometries(shape.geometries(),
                                     PlateCarree(),
                                     edgecolor='#676360',
                                     facecolor='None',
                                     lw=.3)

        if self.lims is not None:
            self.axes.axis(self.lims)

        self.draw()

        self.lims = self.axes.axis()

    def plot(self, data):
        self.create_map()

        if data.shape[0] == 0:
            return

        points = (data[data.lat.notnull()].groupby('callsign').
                  apply(lambda df:
                        df.sort_values('time', ascending=False).head(1)).
                  set_index('callsign')
                  )

        surface = points.alt.isnull()

        if sum(~surface) > 0:
            self.axes.scatter(points[~surface].lon,
                              points[~surface].lat, marker='.',
                              transform=PlateCarree(),
                              c=points[~surface].alt, cmap=self.cmap,
                              vmin=0, vmax=42000)

        if sum(surface) > 0:
            self.axes.scatter(points[surface].lon, points[surface].lat,
                              transform=PlateCarree(),
                              marker='.', color="#333333")

        if self.print_callsign:
            for callsign in points.index:
                d = points.loc[callsign]
                xy = self.projection.transform_point(
                    d.lon, d.lat, PlateCarree())
                self.axes.annotate(" {}".format(callsign), xy=xy,
                                   fontsize=8)

        def plot_flight(flight):
            flight = flight[flight.lat.notnull()]
            if flight.shape[0] >= 2:
                self.axes.plot(flight.lon.dropna().values,
                               flight.lat.dropna().values,
                               transform=PlateCarree(),
                               color="#aa3a3a", lw=1)

                surface = flight.alt.isnull()
                if sum(surface) > 2:
                    self.axes.plot(flight[surface].lon.dropna().values,
                                   flight[surface].lat.dropna().values,
                                   transform=PlateCarree(),
                                   color="#333333", lw=1.5)

        data.groupby('callsign').apply(plot_flight)
        self.draw()

    def plot_flight(self, data):
        self.create_map()
        self.points, = self.axes.plot(data.x.dropna(), data.y.dropna(),
                                      color="#aa3a3a")
        if self.lims is not None:
            self.axes.axis(self.lims)
        self.draw()

    def wheelEvent(self, event):
        if sys.platform == 'darwin':  # rather use pinch
            return
        self.zoom(event.angleDelta().y() > 0, 0.8)

    def gestureEvent(self, event):
        gesture = event.gesture(Qt.PinchGesture)
        self.zoom(gesture.scaleFactor() > 1, 0.9)

    def zoom(self, zoom_in, factor):
        min_x, max_x, min_y, max_y = self.axes.axis()
        if not zoom_in:
            factor = 1.0 / factor

        center_x = .5 * (max_x + min_x)
        delta_x = .5 * (max_x - min_x)
        center_y = .5 * (max_y + min_y)
        delta_y = .5 * (max_y - min_y)

        self.axes.axis((center_x - factor * delta_x,
                        center_x + factor * delta_x,
                        center_y - factor * delta_y,
                        center_y + factor * delta_y))

        self.fig.tight_layout()
        self.lims = self.axes.axis()
        fmt = ", ".join("{:.5e}".format(t) for t in self.lims)
        logging.info('Zooming to {}'.format(fmt))
        self.draw()


class DetailCanvas(FigureCanvasQTAgg):

    def __init__(self, parent=None, width=5, height=4, dpi=100):

        self.fig = Figure(figsize=(width, height), dpi=dpi)

        FigureCanvasQTAgg.__init__(self, self.fig)
        self.setParent(parent)
        FigureCanvasQTAgg.setSizePolicy(self, QSizePolicy.Expanding,
                                        QSizePolicy.Expanding)
        FigureCanvasQTAgg.updateGeometry(self)

    def plot(self, data):

        self.fig.clear()

        ax1 = self.fig.add_subplot(3, 1, 1)
        ax2 = self.fig.add_subplot(3, 1, 2, sharex=ax1)
        ax3 = self.fig.add_subplot(3, 1, 3, sharex=ax1)

        def plot_flight(flight):
            if flight.shape[0] >= 2:

                if 'i_airspeed' in flight.columns:
                    f1 = flight[flight['i_airspeed'].notnull()]
                    if f1.shape[0] > 2:
                        f1.plot.line(x='time', y='i_airspeed',
                                     label=flight.callsign.values[0],
                                     ax=ax2)

                if 'roll' in flight.columns:
                    f1 = flight[flight['roll'].notnull()]
                    if f1.shape[0] > 2:
                        f1.plot.line(x='time', y='roll', style='-o',
                                     label=flight.callsign.values[0],
                                     ax=ax3)

                # keep it last!
                f1 = flight[flight.alt.notnull()]
                if f1.shape[0] > 2:
                    f1.plot.line(x='time', y='alt',
                                 label=flight.callsign.values[0],
                                 ax=ax1)

        data.groupby('callsign').apply(plot_flight)

        self.fig.tight_layout()
        self.draw()
