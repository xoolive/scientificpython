#!/usr/bin/env python3

import sys
import os.path
import importlib

usage = """usage: adsb <command> [<args>, help]

adsb is the entry point to several programs.

    decode      listen to the antenna, feed a sqlite file and dump1090
    enrich      read the sqlite file and enrich it with metadata
    kml         replay traffic in a KML file
    metar       get the METAR data for given airfields
    osm2shp     transform OpenStreetMap files of airports into shapefiles
    query       search for flights, routes, aircraft within the metadata

"""


def main():
    if len(sys.argv) <= 1:
        print(usage)
        exit(2)

    if sys.argv[1] in ["-h", "--h", "help", "--help"]:
        print(usage)
        exit(2)

    a = importlib.import_module("adsb_py.adsb_{}".format(sys.argv[1]))
    return a.main()

