import socket
from datetime import datetime, timedelta, timezone

host = "134.212.189.239"
port = 10003


def next_msg(s):
    while True:
        data = s.recv(2048)
        while len(data) > 10:
            if data[1] == 0x33:
                yield data[:23]
                data = data[23:]
                continue
            if data[1] == 0x32:
                data = data[16:]
                continue
            if data[1] == 0x31:
                data = data[11:]
                continue
            if data[1] == 0x34:
                data = data[23:]
                continue
            it = data.find(0x1a)
            if it < 1:
                break
            data = data[it:]


def main():

    now = datetime.now(timezone.utc)
    curday = now.day
    curfile = open(now.strftime("ADSB_EHS_RAW_%Y%m%d.csv"), 'a')

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((host, port))
        iterator = next_msg(sock)

        for i, bin_msg in enumerate(iterator):
            if len(bin_msg) < 23:
                continue
            msg = ''.join(["{:02x}".format(t) for t in bin_msg])

            # Timestamp decoding
            now = datetime.now(timezone.utc)
            timestamp = int(msg[4:16], 16)
            nanos = timestamp & 0x00003FFFFFFF
            secs = timestamp >> 30
            now = now.replace(hour=0, minute=0, second=0,
                              microsecond=0)
            now += timedelta(seconds=secs,
                             microseconds=nanos / 1000)
            ts = now.timestamp()

            if now.day != curday:
                if now.day == curday + 2: # weird bug
                    now -= timedelta(days=1)
                curday = now.day
                curfile.close()
                curfile = open(now.strftime("ADSB_EHS_RAW_%Y%m%d.csv"), 'a')

            txt = "{:.6f},{}".format(ts, msg[18:])
            print(txt)
            curfile.write("{}\n".format(txt))


if __name__ == '__main__':
    main()
