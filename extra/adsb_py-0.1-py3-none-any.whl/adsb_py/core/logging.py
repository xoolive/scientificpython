import os.path
import logging
from PyQt5.QtWidgets import QMessageBox


def init_logging(logdir):
    fmt = '%(asctime)s:%(msecs)d - %(levelname)s'
    fmt += ' - {%(filename)s:%(lineno)d} %(message)s'

    logging.basicConfig(level=logging.DEBUG,
                        format=fmt,
                        datefmt='%m-%d %H:%M:%S',
                        filename=os.path.join(logdir, 'kamome.log'),
                        filemode='w')
    console = logging.StreamHandler()
    console.setLevel(logging.WARNING)
    console_fmt = logging.Formatter('%(levelname)-8s %(message)s')
    console.setFormatter(console_fmt)
    logging.getLogger('').addHandler(console)


def dont_crash(fn):

    def safe_exec(self, *args, **kwargs):
        try:
            return fn(self, *args, **kwargs)
        except Exception as e:
            logging.exception(e)
            QMessageBox.information(self, type(e).__name__, ''.join(e.args))

    return safe_exec

