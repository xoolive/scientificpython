#!/usr/bin/env python3

import socket
import logging
# import struct
# import os.path
import sqlite3
import threading
import datetime as datetime

from collections import UserDict, namedtuple

import pyModeS as pms
import pyModeS.util as util


MSG40 = namedtuple("MSG40", "alt_fms, alt_mcp, p_baro")
MSG44 = namedtuple("MSG44", "hum, p, temp, wind_speed, wind_dir")
MSG50 = namedtuple("MSG50", "gs, roll, tas, trk, trk_r")
MSG60 = namedtuple("MSG60", "hdg, ias, mach, vert_baro, vert_ins")


class AircraftDict(UserDict):
    def get(self, now, key):
        candidate = self[key]
        if now - candidate.last <= 1800:
            return candidate
        else:
            return self.__missing__(key)

    def __missing__(self, key):
        with aircraft_lock:
            self[key] = value = Aircraft(0, key)
        return value


db, c = None, None
AIRCRAFT = AircraftDict()
aircraft_lock = threading.Lock()
reference_position = None


def next_msg(s):
    while True:
        data = s.recv(2048)
        while len(data) > 10:
            if data[1] == 0x33:
                yield data[:23]
                data = data[23:]
                continue
            if data[1] == 0x32:
                data = data[16:]
                continue
            if data[1] == 0x31:
                data = data[11:]
                continue
            if data[1] == 0x34:
                data = data[23:]
                continue
            it = data.find(0x1a)
            if it < 1:
                break
            data = data[it:]


def init_db(filename):
    global db, c
    db = sqlite3.connect(filename)
    c = db.cursor()
    query = """CREATE TABLE IF NOT EXISTS "positions" (
              "icao"      INTEGER KEY NOT NULL,
              "callsign" TEXT NOT NULL,
              "timestamp" INTEGER NOT NULL,
              "alt"       INTEGER,
              "lat"       REAL,
              "lon"       REAL
          );"""
    c.execute(query)
    query = """CREATE TABLE IF NOT EXISTS "surface" (
              "icao"      INTEGER KEY NOT NULL,
              "timestamp" INTEGER NOT NULL,
              "callsign" TEXT NOT NULL,
              "lat"       REAL,
              "lon"       REAL
          );"""
    c.execute(query)
    query = """CREATE TABLE IF NOT EXISTS "vectors" (
              "icao"      INTEGER KEY NOT NULL,
              "timestamp" INTEGER NOT NULL,
              "callsign" TEXT NOT NULL,
              "speed"     INTEGER,
              "heading"   REAL,
              "vertical"  INTEGER
          );"""
    c.execute(query)
    query = """CREATE TABLE IF NOT EXISTS "callsigns" (
              "icao"     INTEGER KEY NOT NULL,
              "callsign" TEXT NOT NULL,
              "start"    INTEGER NOT NULL,
              "lastseen" INTEGER NOT NULL,
              PRIMARY KEY (icao, callsign, start)
          );"""
    c.execute(query)
    # BDS 4,0 Selected vertical intention
    query = """CREATE TABLE IF NOT EXISTS "intention" (
              "icao"      INTEGER KEY NOT NULL,
              "timestamp" INTEGER NOT NULL,
              "callsign" TEXT NOT NULL,
              "alt_fms"   INTEGER,
              "alt_mcp"   INTEGER,
              "p_baro"    REAL
          );"""
    c.execute(query)
    # BDS 4,4 Meteorological routine air report
    query = """CREATE TABLE IF NOT EXISTS "meteo" (
              "icao"        INTEGER KEY NOT NULL,
              "timestamp"   INTEGER NOT NULL,
              "callsign" TEXT NOT NULL,
              "humidity"    REAL,
              "p_static"    INTEGER,
              "temperature" REAL,
              "wind_speed"  INTEGER,
              "wind_dir"    REAL
          );"""
    c.execute(query)
    # BDS 5,0 Track and turn report
    query = """CREATE TABLE IF NOT EXISTS "tracks" (
              "icao"        INTEGER KEY NOT NULL,
              "timestamp"   INTEGER NOT NULL,
              "callsign" TEXT NOT NULL,
              "groundspeed" INTEGER,
              "roll"        REAL,
              "t_airspeed"  INTEGER,
              "track"       REAL,
              "track_rate"  REAL
          );"""
    c.execute(query)
    # BDS 6,0 Heading and speed report
    query = """CREATE TABLE IF NOT EXISTS "speed" (
              "icao"       INTEGER KEY NOT NULL,
              "timestamp"  INTEGER NOT NULL,
              "callsign" TEXT NOT NULL,
              "heading"    REAL,
              "i_airspeed" INTEGER,
              "mach"       REAL,
              "vertrate_b" INTEGER,
              "vertrate_i" INTEGER
          );"""
    c.execute(query)
    db.commit()

    query = "select * from callsigns;"
    for icao, callsign, start, b in c.execute(query).fetchall():
        aircraft = Aircraft(start, icao)
        aircraft.cs = callsign
        aircraft.first = start
        aircraft.last = b


class Aircraft(object):

    def __init__(self, start, icao24):
        self.icao24 = icao24
        self.first = start
        self.last = start
        self.cs = "UNKNOWN"
        self.last_msg = None
        self.pos = (None, None)
        self.alt = None
        AIRCRAFT[icao24] = self

    def __repr__(self):
        return "{}: {}, {}, {}".format(self.icao24, self.cs, *self.pos)

    @property
    def callsign(self):
        return self.cs

    @callsign.setter
    def callsign(self, args):
        # callsign may change!
        cs, now = args
        if cs != self.cs: # or now - self.last > 1800:  # 30 minutes
            self.first = now
        self.cs = cs
        self.last = now
        query = """insert or replace into callsigns
        (icao, callsign, start, lastseen)
        values ({}, '{}', {}, {});
        """.format(self.icao24, self.cs, self.first, self.last)
        c.execute(query)

    @property
    def bds40(self): return None

    @bds40.setter
    def bds40(self, args):
        msg, now = args
        values = {k: v if v is not None else 'NULL'
                  for k, v in msg._asdict().items()}
        query = """insert or replace into intention
        (icao, timestamp, callsign, alt_fms, alt_mcp, p_baro)
        values ({}, {}, '{}', {alt_fms}, {alt_mcp}, {p_baro});"""
        query = query.format(self.icao24, now, self.callsign, **values)
        c.execute(query)

    @property
    def bds44(self): return None

    @bds44.setter
    def bds44(self, args):
        msg, now = args
        values = {k: v if v is not None else 'NULL'
                  for k, v in msg._asdict().items()}
        query = """insert or replace into meteo
        (icao, timestamp, callsign, humidity, p_static, temperature,
        wind_speed, wind_dir)
        values ({}, {}, '{}', {hum}, {p}, {temp}, {wind_speed}, {wind_dir});"""
        query = query.format(self.icao24, now, self.callsign, **values)
        c.execute(query)

    @property
    def bds50(self): return None

    @bds50.setter
    def bds50(self, args):
        msg, now = args
        values = {k: v if v is not None else 'NULL'
                  for k, v in msg._asdict().items()}
        query = """insert or replace into tracks
        (icao, timestamp, callsign, groundspeed, roll, t_airspeed, track, track_rate)
        values ({}, {}, '{}', {gs}, {roll}, {tas}, {trk}, {trk_r});"""
        query = query.format(self.icao24, now, self.callsign, **values)
        c.execute(query)

    @property
    def bds60(self): return None

    @bds60.setter
    def bds60(self, args):
        msg, now = args
        values = {k: v if v is not None else 'NULL'
                  for k, v in msg._asdict().items()}
        query = """insert or replace into speed
        (icao, timestamp, callsign, heading, i_airspeed, mach, vertrate_b, vertrate_i)
        values ({}, {}, '{}', {hdg}, {ias}, {mach}, {vert_baro}, {vert_ins});"""
        query = query.format(self.icao24, now, self.callsign, **values)
        c.execute(query)

    @property
    def surface(self):
        return self.s_pos

    @surface.setter
    def surface(self, args):
        self.s_pos, now = args
        query = """insert or replace into surface
        (icao, timestamp, callsign, lat, lon)
        values ({}, {}, '{}', {}, {})""".format(self.icao24, now, self.callsign,
                                              *self.s_pos)
        c.execute(query)

    @property
    def velocity(self): return self.vectors

    @velocity.setter
    def velocity(self, args):
        self.vectors, now = args

        query = """insert into vectors
        (icao, timestamp, callsign, speed, heading, vertical)
        values ({}, {}, '{}', {}, {}, {});""".format(self.icao24, now,
                                                   self.callsign, *self.vectors)
        c.execute(query)

    @property
    def position_msg(self): return None

    @position_msg.setter
    def position_msg(self, args):
        msg, now = args
        flag = pms.adsb.oe_flag(msg)
        if self.last_msg is None:
            self.last_msg = msg, now
            return
        if now - self.last_msg[1] > 10:  # careful, this is about seconds
            self.last_msg = msg, now
            return
        if pms.adsb.oe_flag(self.last_msg[0]) == flag:
            self.last_msg = msg, now
            return
        if flag == 0:
            p = pms.adsb.position(msg, self.last_msg[0],
                                  now, self.last_msg[1])
        else:
            p = pms.adsb.position(self.last_msg[0], msg,
                                  self.last_msg[1], now)
        if p is None:
            return
        self.pos = p
        self.last_msg = args
        if self.pos[0] is None:
            return
        self.alt = pms.adsb.altitude(msg)
        query = """insert into positions
        (icao, timestamp, callsign, alt, lat, lon)
        values ({}, {}, '{}', {}, {}, {});"""
        query = query.format(self.icao24, now, self.callsign,
                             self.alt, *self.pos)
        c.execute(query)

# from datetime import datetime
# f= open("/home/xo/month/tiebreak.log", "w")
def decode_ehs(msg, now):

    icao24 = int(pms.ehs.icao(msg), 16)
    ac = AIRCRAFT.get(now, icao24)
    bds = pms.ehs.BDS(msg)

#     if isinstance(bds, list) and (len(bds) > 1):
#         msg = "Need to discriminate for {} ({}): {}"
#         logging.warn(msg.format(ac.callsign, icao24, bds))

#     if bds == ['BDS50', 'BDS60']:
#         f.write("{} {} {}\n".format(now, msg, datetime.fromtimestamp(now)))

    if bds == "BDS20":
        callsign = pms.ehs.callsign(msg).strip('_')
        ac.callsign = callsign, now

    if bds == "BDS40":
        fms, mcp = pms.ehs.alt40fms(msg), pms.ehs.alt40mcp(msg),
        p = pms.ehs.p40baro(msg)
        ac.bds40 = MSG40(fms, mcp, p), now

    if bds == "BDS44":
        hum = pms.ehs.hum44(msg)
        p, t = pms.ehs.p44(msg), pms.ehs.temp44(msg)
        wind = pms.ehs.wind44(msg)
        wind = wind if wind is not None else (None, None)
        ac.bds44 = MSG44(hum, p, t, *wind), now

    if bds == "BDS50":
        gs, roll = pms.ehs.gs50(msg), pms.ehs.roll50(msg)
        tas = pms.ehs.tas50(msg)
        trk, trk_r = pms.ehs.trk50(msg), pms.ehs.rtrk50(msg)
        ac.bds50 = MSG50(gs, roll, tas, trk, trk_r), now

    if bds == "BDS60":
        hdg = pms.ehs.hdg60(msg)
        ias, mach = pms.ehs.ias60(msg), pms.ehs.mach60(msg)
        vb, vi = pms.ehs.vr60baro(msg), pms.ehs.vr60ins(msg)
        ac.bds60 = MSG60(hdg, ias, mach, vb, vi), now


def decode_loop(host, port, dump_flag=False):
    dump1090 = None
    if dump_flag:
        try:
            dump1090 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            dump1090.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            dump1090.connect(('localhost', 30001))
        except ConnectionRefusedError:
            msg = "dump1090 is not listening on port 30001"
            raise ConnectionRefusedError(msg)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if host == "localhost":
            s.bind((host, port))
            s.listen(1)
            conn, addr = s.accept()
            print("Connected.")
        else:
            print("Connecting {}:{}".format(host, port))
            s.connect((host, port))
            conn = s
            print("Connected.")
        decode_iter(next_msg(conn), dump1090, port == 10003)


def decode_iter(iterator, dump1090=None, radarcape=False):
    # fh = open('dump.bin', 'ab')
    # bin_struct = struct.Struct('d' + 'i' * 14)
    for i, bin_msg in enumerate(iterator):
        if len(bin_msg) < 23:
            continue
        msg = ''.join(["{:02x}".format(t) for t in bin_msg])

        # Timestamp decoding
        now = datetime.datetime.now(datetime.timezone.utc)
        if radarcape:
            timestamp = int(msg[4:16], 16)
            nanos = timestamp & 0x00003FFFFFFF
            secs = timestamp >> 30
            now = now.replace(hour=0, minute=0, second=0,
                              microsecond=0)
            now += datetime.timedelta(seconds=secs,
                                microseconds=nanos / 1000)
        now = now.timestamp()
        # fh.write(bin_struct.pack(now, *bin_msg[9:]))

        decode_msg(now, msg[18:], dump1090)

        if i % 100 == 99:
            db.commit()

            global reference_position
            pos = list(a.pos for a in AIRCRAFT.values()
                       if a.alt is not None and a.alt < 5000 and
                       (now - a.last) < 1200)  # 20 min
            n = len(pos)
            if n > 0:
                lat = sum(a[0] for a in pos) / n
                lon = sum(a[1] for a in pos) / n
                reference_position = {'lat_ref': lat, 'lon_ref': lon}


def decode_msg(now, msg, dump1090):

    if len(msg) != 28:
        return

    if dump1090 is not None:
        dump1090.sendall("*{};\n".format(msg).encode())

    if pms.df(msg) in (20, 21):
        decode_ehs(msg, now)
        return

    if pms.df(msg) == 17:
        decode_adsb(msg, now)
        return


def decode_adsb(msg, now):

    if int(pms.crc(msg, encode=False), 2) != 0:
        return

    icao24 = int(pms.adsb.icao(msg), 16)
    ac = AIRCRAFT.get(now, icao24)

    tc = pms.adsb.typecode(msg)

    if tc >= 1 and tc <= 4:
        callsign = pms.adsb.callsign(msg).strip('_')
        ac.callsign = callsign, now

    if tc >= 5 and tc <= 8:
        if reference_position is not None:
            s_pos = pms.adsb.surface_position_with_ref(
                msg, **reference_position)
            ac.surface = s_pos, now

    if tc >= 9 and tc <= 18:
        ac.position_msg = msg, now

    if tc == 19:
        velocity = pms.adsb.velocity(msg)[:-1]
        ac.velocity = velocity, now


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(
        description="Decode ADSB messages and fill a sqlite database file.")
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "-s", "--host",
        help="the hostname to listen to (default: localhost)",
        default="localhost")
    group.add_argument(
        "-d", "--dump", action="store_true",
        help="hostname:port set to 127.0.0.1:30005")
    group.add_argument(
        "-c", "--cert", action="store_true",
        help="hostname:port set to 134.212.189.239:10003")
    group.add_argument(
        "-l", "--localhost", action="store_true",
        help="nc -l <host> | nc localhost <port>")
    parser.add_argument(
        "-p", "--port", type=int,
        help="the port to listen to (default: 30005)",
        default=30005)
    parser.add_argument(
        "-f", "--file",
        help="the database file where to store data (default: adsb.db)",
        default="adsb.db")
    parser.add_argument(
        "-e", "--feed", action="store_true",
        help="feed a local dump1090 server on the appropriate port")
    args = parser.parse_args()

    if args.cert:
        args.host = "134.212.189.239"
        args.port = 10003

    if args.dump:
        args.host = "127.0.0.1"
        args.port = 30005

    # Create the database file
    init_db(args.file)

    # Start the decoding infernal loop
    decode_loop(args.host, int(args.port), args.feed)
