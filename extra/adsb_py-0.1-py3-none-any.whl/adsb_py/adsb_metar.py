#!/usr/bin/env python3

import urllib.request as urlrequest

from bs4 import BeautifulSoup

# url = "http://fr.allmetsat.com/metar-taf/france.php?icao="
url = "http://www.ogimet.com/display_metars2.php?lang=en&lugar={icao}&tipo=ALL&ord=REV&nil=SI&fmt=txt&ano={ano}&mes={mes}&day={day}&hora=00&anof={anof}&mesf={mesf}&dayf={dayf}&horaf=00&minf=00&send=send"  # noqa: E501
user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:46.0) Gecko/20100101 Firefox/46.0"  # noqa: E501
headers = {'User-Agent': user_agent}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Get METAR information for given airport.")

    parser.add_argument(
        "icao", help="ICAO identifiers for given airport")

    parser.add_argument(
        "start", help="Start date (e.g. 20170101)")

    parser.add_argument(
        "stop", help="End date (e.g. 20170101)")

    args = parser.parse_args()

    request = {'icao': args.icao,
               'ano': args.start[:4],
               'mes': args.start[4:6],
               'day': args.start[6:],
               'anof': args.stop[:4],
               'mesf': args.stop[4:6],
               'dayf': args.stop[6:]}

    req = urlrequest.Request(url.format(**request),
                             None, headers=headers)
    html = urlrequest.urlopen(req).read()
    raw = html.decode()

    soup = BeautifulSoup(raw, 'lxml')
    elt = soup.find('pre')

    print(elt.contents[0])
