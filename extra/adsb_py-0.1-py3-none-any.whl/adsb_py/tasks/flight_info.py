from PyQt5 import QtCore

import random
import logging
import sqlite3
import numpy as np
import pandas as pd

from collections import namedtuple
from concurrent.futures import ThreadPoolExecutor, as_completed

from adsb_py.core.callsigns import Planefinder, FlightXML3

field = namedtuple('field',
                   'callsign airline origin o_city destination d_city date')

class FlightInfo():

    def __init__(self, parent=None):
        self.parent = parent
        self.query_holder = [Planefinder()]
        self.results = []

        if parent is None:
            return

        username = parent.config.get('FlightXML3', 'user', fallback=None)
        apikey = parent.config.get('FlightXML3', 'apikey', fallback=None)

        if username is not None and apikey is not None:
            try:
                self.query_holder.append(FlightXML3(username, apikey))
            except Exception as e:
                logging.exception(e)

    def __del__(self):
        self.update_db()

    def get_info(self, callsign):
        return Planefinder().get_info(callsign)

    def get_info_fallback(self, callsign):
        for q in self.query_holder:
            rep = q.get_info(callsign)
            if rep is not None:
                return rep
        return None

    def get_info_update(self, get_info, callsign):
        res = get_info(callsign)
        if res is None:
            return res

        msg = 'Found {}: from {} to {}'
        logging.debug(msg.format(res.callsign, res.origin, res.destination))

        a = self.parent.airports

        o = a[(a.icao == res.origin) | (a.iata == res.origin)]
        if o.shape[0] == 0:
            return

        self.parent.tableView.model().updateLine(
            res.callsign, "origin", o.icao.values[0])
        self.parent.tableView.model().updateLine(
            res.callsign, "o_city", o.city.values[0])


        d = a[(a.icao == res.destination) | (a.iata == res.destination)]
        if d.shape[0] == 0:
            return

        self.parent.tableView.model().updateLine(
            res.callsign, "destination", d.icao.values[0])
        self.parent.tableView.model().updateLine(
            res.callsign, "d_city", d.city.values[0])

        self.results.append(field(res.callsign, res.airline,
                                  o.icao.values[0], o.city.values[0],
                                  d.icao.values[0], d.city.values[0],
                                  res.date))

        return res

    def update_db(self):

        if len(self.results) == 0 or self.parent is None:
            return

        results = pd.DataFrame(self.results)
        self.results.clear()

        connector = sqlite3.connect(self.parent.callsigns_db)
        sub = results['callsign airline origin destination date'.split()]
        sub.to_sql('callsigns', connector, if_exists='append', index=False)
        connector.commit()

        results = results.assign(
            date=results.date.apply(
                lambda x: datetime.strptime(x, "%Y-%m-%d")
                if isinstance(x, str) else np.datetime64('NaT')))

        self.parent.callsigns_info = pd.concat(
            [self.parent.callsigns_info, results])


class FlightInfoThread(QtCore.QThread):

    def __init__(self, parent):
        super(FlightInfoThread, self).__init__()
        self.fi = FlightInfo(parent)
        self.parent = parent
        self.nope = []

    def run(self):

        data = self.parent.tableView.model()._df
        callsigns = data[data.origin.isnull()].index.tolist()
        callsigns = [cs for cs in callsigns if cs not in self.nope]
        self.conn = sqlite3.connect(self.parent.callsigns_db)

        if len(callsigns) > 10:
            callsigns = random.sample(callsigns, 10)
        if len(callsigns) == 0:
            return

        logging.info("Fetching info about {}".format(', '.join(callsigns)))

        def callback(callsign):
            try:
                result = self.fi.get_info_update(self.fi.get_info, callsign)
                return (callsign, result)
            except Exception as e:
                logging.exception(e)
                return callsign, None

        with ThreadPoolExecutor(4) as executor:
            todo = []
            for cs in callsigns:
                todo.append(executor.submit(callback, cs))
            for future in as_completed(todo):
                try:
                    code, res = future.result()
                    if res is None:
                        raise Exception

                except Exception as e:
                    msg = 'Recording {} as not to search again'
                    logging.warn(msg.format(code))
                    self.nope.append(code)

            try:
                self.fi.update_db()
            except Exception as e:
                logging.exception(e)
