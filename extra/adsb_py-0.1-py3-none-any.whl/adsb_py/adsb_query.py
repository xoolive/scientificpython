#!/usr/bin/env python3

import os.path
import sqlite3
from collections import namedtuple
from datetime import datetime as dt

metadata_db = os.path.join(os.path.expanduser("~"),
                           "Documents", "data", "metadata.db")

metadata_connector = None
metadata_cursor = None

_airport_rec = "airport, city, country, iata, icao, lat, lon, alt"
_airline_rec = "airline, iata, icao, country"
_callsign_rec = "callsign, provenance, destination, first_tracked"
_aircraft_rec = """adshex, registration, aircraft, model, series, airline,
                   delivered, first_tracked"""

AirportRecord = namedtuple("AirportRecord", _airport_rec)
AirlineRecord = namedtuple("AirlineRecord", _airline_rec)
CallsignRecord = namedtuple("CallsignRecord", _callsign_rec)
AircraftRecord = namedtuple("AircraftRecord", _aircraft_rec)


class Airport(AirportRecord):
    def __repr__(self):
        msg = "{} / {} \t{} {} ({}) \n\tlat: {} lon: {} alt: {}"
        return msg.format(self.icao, self.iata,
                          self.city, self.airport, self.country,
                          self.lat, self.lon, self.lat)


class Airline(AirlineRecord):
    def __repr__(self):
        msg = "{} / {}  \t{} ({})"
        return msg.format(self.iata, self.icao, self.airline, self.country)


class Callsign(CallsignRecord):
    def __repr__(self):
        msg = "{:<8}: {:<4} ({}) {:<4} ({}), first seen: {}"
        from_ = next(airport_query(self.provenance), None)
        from_ = from_.city if from_ is not None else "???"
        dest_ = next(airport_query(self.destination), None)
        dest_ = dest_.city if dest_ is not None else "???"
        return msg.format(self.callsign, self.provenance, from_,
                          self.destination, dest_, self.first_tracked)


class Aircraft(AircraftRecord):
    def __repr__(self):
        msg = "{} ({}) {} \t {}{} \tsince: {} ({})"
        return msg.format(hex(self.adshex)[2:], self.registration,
                          self.airline, self.model, orempty(self.series),
                          self.delivered, self.first_tracked.split()[0])


def init_db(metadata_db):

    global metadata_connector, metadata_cursor

    metadata_connector = sqlite3.connect(metadata_db)
    metadata_cursor = metadata_connector.cursor()


def date2str(timestamp):
    return dt.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


def orempty(str):
    if str == "N/A": return ""
    return "-" + str


def callsign_query(callsign, display=True, recursion=0):
    query = "select * from routes where callsign='{}'"
    metadata_cursor.execute(query.format(callsign))
    return map(Callsign._make, metadata_cursor.fetchall())


def departing_query(departing, display=True):
    query = "select * from routes where provenance='{}'"
    metadata_cursor.execute(query.format(departing))
    return map(Callsign._make, metadata_cursor.fetchall())


def arriving_query(destination, display=True):
    query = "select * from routes where destination='{}'"
    metadata_cursor.execute(query.format(destination))
    return map(Callsign._make, metadata_cursor.fetchall())


def airport_query(airport):
    query = """select * from airport where airport='{0}' or
    city='{0}' or country='{0}' or iata='{0}' or icao='{0}' order by city"""
    metadata_cursor.execute(query.format(airport))
    return map(Airport._make, metadata_cursor.fetchall())


def airline_query(airline, verbose=True, display=True):
    query = """select * from airline where airline='{0}' or
    country='{0}' or iata='{0}' or icao='{0}'"""
    metadata_cursor.execute(query.format(airline))
    return map(Airline._make, metadata_cursor.fetchall())


def aircraft_from_airline(airline):
    query = "select * from aircraft where airline='{}' order by registration"
    metadata_cursor.execute(query.format(airline.iata))
    return map(Aircraft._make, metadata_cursor.fetchall())


def adshex_query(adshex):
    query = "select * from aircraft where adshex='{}'"
    metadata_cursor.execute(query.format(adshex))
    return map(Aircraft._make, metadata_cursor.fetchall())


def registration_query(registration):
    query = "select * from aircraft where registration='{}'"
    metadata_cursor.execute(query.format(registration))
    return map(Aircraft._make, metadata_cursor.fetchall())


def get_callsign(callsign, display=True, recursion=0):
    for r in sorted():
        if not display:
            return r
        print("{}: {} ({}) {} ({}), first seen: {}".format(
            r.callsign, r.provenance, airport_query(r.provenance)[0],
            r.destination, airport_query(r.destination)[0],
            r.first_tracked))


init_db(metadata_db)

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(
        description="Query various ADSB metadata.")

    parser.add_argument(
        "metadata_db", nargs="?",
        help="path to the metadata data file (optional)")

    parser.add_argument("-v", action="store_true",
                        help="more verbose")

    group = parser.add_mutually_exclusive_group()

    group.add_argument("-c", dest="callsign",
                       help="query info for a specified callsign")
    group.add_argument("-x", dest="adshex",
                       help="query info for a specified adshex")
    group.add_argument("-r", dest="reg",
                       help="query info for a specified registration")
    group.add_argument("-f", dest="from",
                       help="query info for a specified departing airport")
    group.add_argument("-t", dest="to",
                       help="query info for a specified arriving airport")
    group.add_argument("-p", dest="airport",
                       help="query info for a specified airport")
    group.add_argument("-l", dest="airline",
                       help="query info for a specified airline")

    args = parser.parse_args()

    if args.metadata_db is not None:
        init_db(args.metadata_db)

    if args.callsign is not None:
        for callsign in callsign_query(args.callsign):
            print(callsign)
    if args.adshex is not None:
        for aircraft in adshex_query(int("0x" + args.adshex, 16)):
            print(aircraft)
    if args.reg is not None:
        for aircraft in registration_query(args.reg):
            print(aircraft)

    from_ = [v for k, v in args._get_kwargs() if k == "from"][0]
    if from_ is not None:
        for callsign in departing_query(from_):
            print(callsign)
    if args.to is not None:
        for callsign in arriving_query(args.to):
            print(callsign)
    if args.airport is not None:
        for airport in airport_query(args.airport):
            print(airport)
    if args.airline is not None:
        for airline in airline_query(args.airline):
            print(airline)
            print()
            if args.v:
                for aircraft in aircraft_from_airline(airline):
                    print(aircraft)
                print()
                print(airline)
