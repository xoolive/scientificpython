from typing import NamedTuple

import pandas as pd
# from ..data.basic.airport import Airport


class DistanceAirport(NamedTuple):
    distance: float
    # TODO I would like to specify a 'Point' trait in place of NamedTuple
    airport: NamedTuple


class DistancePointTrajectory(NamedTuple):
    distance: float
    name: str
    point: pd.Series
