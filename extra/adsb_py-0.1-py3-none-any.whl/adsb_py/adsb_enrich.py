#!/usr/bin/env python3

import re
import csv
import time
import sqlite3

from datetime import date as d
from datetime import datetime as dt

import urllib.request as urlrequest

metadata_connector = None
metadata_cursor = None

adsb_connector = None
adsb_cursor = None

aircraft_table = """
create table if not exists "aircraft" (
    "adshex"        int primary key not null,
    "registration"  text not null,
    "aircraft"      text,
    "model"         text,
    "series"        text,
    "airline"       text,
    "delivered"     text,
    "first_tracked" text
    );
"""

routes_table = """
create table if not exists "routes" (
    "callsign"      text primary key not null,
    "provenance"    text,
    "destination"   text,
    "first_tracked" text
);
"""

airport_table = """
create table if not exists "airport" (
    "airport" text,
    "city"    text not null,
    "country" text not null,
    "iata"    text,
    "icao"    text not null,
    "lat"     float(24),
    "lon"     float(24),
    "alt"     int,
    primary key (iata, icao));
"""

airline_table = """
create table if not exists "airline" (
    "airline" text,
    "iata"    text,
    "icao"    text not null,
    "country" text
    );
"""


def init_db(metadata_db, adsb_db):

    global metadata_connector, metadata_cursor
    global adsb_connector, adsb_cursor

    metadata_connector = sqlite3.connect(metadata_db)
    metadata_cursor = metadata_connector.cursor()
    metadata_cursor.execute(aircraft_table)
    metadata_cursor.execute(routes_table)

    adsb_connector = sqlite3.connect("file:" + adsb_db + "?mode=ro", uri=True)
    adsb_cursor = adsb_connector.cursor()

    metadata_cursor.execute("select * from routes")
    callsigns = {t[0]: (t[1], t[2]) for t in metadata_cursor.fetchall()}

    print("Already {} callsigns in database".format(len(callsigns)))

    metadata_cursor.execute("select registration from aircraft")
    known_aircraft = set(("/data/aircraft/" + i[0])
                         for i in metadata_cursor.fetchall())

    print("Already {} aircraft in database".format(len(known_aircraft)))

    return callsigns, known_aircraft


pf_url = "https://planefinder.net/"

user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:46.0)"
user_agent += " Gecko/20100101 Firefox/46.0"
headers = {'User-Agent': user_agent}

query_route = """insert into routes ('callsign', 'provenance', 'destination',
                  'first_tracked') values ('{}', '{}', '{}', '{}');"""

query_aircraft = """insert or replace into aircraft ('adshex', 'registration',
                        'aircraft' , 'model', 'series', 'airline', 'delivered',
                        'first_tracked') values
                        ('{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}');"""

URL = "https://raw.githubusercontent.com/jpatokal/openflights/master/data/"


def enrich_openflights():

    metadata_cursor.execute(airport_table)
    metadata_cursor.execute(airline_table)

    req = urlrequest.Request(URL + "airports.dat", None, headers)
    html = urlrequest.urlopen(req)
    reader = csv.reader([p.decode() for p in html.readlines()], delimiter=',')
    for row in reader:
        if row[5] == "\\N": row[5] = ""
        query = """insert or replace into airport
        ('airport', 'city', 'country' , 'iata', 'icao', 'lat', 'lon', 'alt')
        values (\"{}\", \"{}\", \"{}\", '{}', '{}', '{}', '{}', '{}');"""
        query = query.format(*row[1:9])
        try:
            metadata_cursor.execute(query)
        except:
            print("Warning: Failed to execute query:\n{}".format(query))
    metadata_connector.commit()

    req = urlrequest.Request(URL + "airlines.dat", None, headers)
    html = urlrequest.urlopen(req)
    reader = csv.reader([p.decode() for p in html.readlines()], delimiter=',')
    for row in reader:
        query = """insert or replace into airline
        ('airline' , 'iata', 'icao', 'country')
        values (\"{}\", \"{}\", \"{}\", \"{}\");"""
        query = query.format(row[1], row[3], row[4], row[6])
        metadata_cursor.execute(query)

    metadata_connector.commit()


def loop_over_callsigns(callsigns, known_aircraft):

    adsb_cursor.execute("select distinct icao, callsign from callsigns")
    aircraft = adsb_cursor.fetchall()

    metadata_cursor.execute("select adshex from aircraft")
    known_adshex = set((i[0]) for i in metadata_cursor.fetchall())

    registrations = set()

    for adshex, callsign in ((i[0], i[1].strip()) for i in aircraft):
        try:
            if (adshex not in known_adshex or
                    callsign not in callsigns) and callsign != "":

                url = urlrequest.urljoin(pf_url, "/data/flight/" + callsign)
                print(url)

                req = urlrequest.Request(url, None, headers)
                html = urlrequest.urlopen(req).read()
                raw = html.decode()

                if adshex not in known_adshex:
                    regex = "/data/aircraft/[A-Za-z0-9\-]*"
                    for ac in re.finditer(regex, raw):
                        registrations.add(ac.group())

                if callsign not in callsigns:
                    v = []
                    regex = "/data/airport/[A-Za-z0-9\-]*"
                    for i, p in enumerate(re.finditer(regex, raw)):
                        v.append(p.group().split("/")[3])
                        if i >= 1: break

                    try:
                        query = query_route.format(callsign, v[0], v[1],
                                                   str(d.today()))
                        metadata_cursor.execute(query)
                        callsigns[callsign] = v[0], v[1]
                    except: pass

                time.sleep(1)
        except:
            print("URLError + sleep 10 s")
            time.sleep(10)

    return registrations - known_aircraft


def loop_over_aircraft(registrations):
    for aircraft in registrations:

        url = urlrequest.urljoin("https://planefinder.net/", aircraft)
        print(url)

        req = urlrequest.Request(url, None, headers)
        html = urlrequest.urlopen(req).read()
        raw = html.decode()

        dic = {}

        title_iter = re.finditer('<span class="title">(.*)</span>', raw)
        long_regex = '<span class="value">((.*)|\n<a .*>.*</a>\n)</span>'
        value_iter = re.finditer(long_regex, raw)

        for (i, j) in zip(title_iter, value_iter):
            dic[i.group(1)] = j.group(1)

        if (len(dic) == 0): continue

        try:
            dic["Airline name"] = re.search("data/airline/([A-Z0-9]*)",
                                            dic["Airline name"]).group(1)
        except:
            dic["Airline name"] = "N/A"

        query = query_aircraft.format(
            int("0x" + dic['ADSHEX'], 0), dic['Reg No.'], dic['Aircraft'],
            dic['Model'], dic['Series'], dic['Airline name'], dic['Delivered'],
            dt.utcnow().strftime("%Y-%m-%d %H:%M:%S"))

        metadata_cursor.execute(query)
        metadata_connector.commit()


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(
        description="Enrich ADSB metadata from a adsb.db file.")

    parser.add_argument(
        "-q", "--query", action="store_true",
        help="only display the amount of data in the metadata file")

    parser.add_argument(
        "--airport", action="store_true",
        help="fetch data about airfields and airlines")

    parser.add_argument(
        "adsb_db", default="adsb.db",
        help="path to the ADSB data (default adsb.db)")

    parser.add_argument(
        "metadata_db", default="metadata.db",
        help="path to the metadata data file (default: metadata.db)")

    args = parser.parse_args()

    init_data = init_db(args.metadata_db, args.adsb_db)

    if args.airport:
        enrich_openflights()
    elif not args.query:
        loop_over_aircraft(loop_over_callsigns(*init_data))
