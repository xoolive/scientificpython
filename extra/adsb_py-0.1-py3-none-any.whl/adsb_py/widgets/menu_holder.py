import os.path
import logging

from PyQt5.QtWidgets import QAction, QFileDialog, qApp
from adsb_py.core.logging import dont_crash
from ..tasks import DataHolder


class MenuHolder():

    def __init__(self, *args, **kwargs):

        super(MenuHolder, self).__init__(*args, **kwargs)

        self.menubar = self.menuBar()

        openAct = QAction('Open data file', self)
        openAct.setShortcut('Ctrl+O')
        openAct.setStatusTip('Open and explore data file')
        openAct.triggered.connect(self.openFile)

        screenshotAct = QAction('Take screenshot', self)
        screenshotAct.setShortcut('Ctrl+P')
        screenshotAct.triggered.connect(self.save_figure)

        shapefileAct = QAction('Load shapefile', self)
        shapefileAct.setShortcut('Ctrl+S')
        shapefileAct.setStatusTip('Load and print shapefile')
        shapefileAct.triggered.connect(self.loadShapefile)

        saveShapesAct = QAction('Save shapefiles', self)
        saveShapesAct.triggered.connect(self.saveShapes)

        exitAct = QAction('Exit', self)
        exitAct.setShortcut('Ctrl+Q')
        exitAct.setStatusTip('Exit application')
        exitAct.triggered.connect(qApp.quit)

        fileMenu = self.menubar.addMenu('&File')
        fileMenu.addAction(openAct)
        self.addAction(openAct)
        fileMenu.addAction(screenshotAct)
        self.addAction(screenshotAct)
        fileMenu.addSeparator()
        fileMenu.addAction(shapefileAct)
        self.addAction(shapefileAct)
        fileMenu.addAction(saveShapesAct)
        self.addAction(saveShapesAct)
        fileMenu.addSeparator()
        fileMenu.addAction(exitAct)
        self.addAction(exitAct)

        # -- View menu --
        viewMenu = self.menubar.addMenu('&View')

        switchCSAct = QAction('Print callsigns', self, checkable=True)
        switchCSAct.setShortcut('Ctrl+Shift+C')
        switchCSAct.toggled.connect(self.switch_callsign)
        viewMenu.addAction(switchCSAct)
        self.addAction(switchCSAct)

        switchLTAct = QAction('Show logs', self, checkable=True)
        switchLTAct.setShortcut('Ctrl+Shift+L')
        switchLTAct.toggled.connect(self.switch_logtab)
        viewMenu.addAction(switchLTAct)
        self.addAction(switchLTAct)

        # -- Projections menu --
        projMenu = self.menubar.addMenu('&Maps')
        projs = self.config.get('maps', 'settings', fallback=None)
        if projs is not None:
            for settings in [s.strip() for s in projs.split(',')]:
                logging.debug('adding callback for {}'.format(settings))
                shortcut = self.config.get(settings, 'shortcut', fallback="")
                curproj = QAction('Switch to {}'.format(settings), self)
                curproj.setShortcut(shortcut)
                curproj.setStatusTip('Switch to {}'.format(settings))
                curproj.triggered.connect(self.switch_settings(settings))
                projMenu.addAction(curproj)
                self.addAction(curproj)

    @dont_crash
    def openFile(self, *args, **kwargs):
        options = {
            'caption': 'Open file',
            # 'filter': "Sqlite3 files (*.db);;Pandas DataFrame (*.pkl)",
            'filter': "Data files (*.db *.pkl)",
            'directory': os.path.expanduser("~"),
        }

        self.filename = QFileDialog.getOpenFileName(self, **options)[0]
        if self.filename == "":
            return
        self.file_button.setText(os.path.basename(self.filename))
        self.holder = DataHolder.open(self.filename)

        if self.offline_button.isChecked():
            self.updateData()

    @dont_crash
    def loadShapefile(self, *args, **kwargs):
        options = {
            'caption': 'Load shapefile',
            'filter': '*.shp',
            'directory': os.path.expanduser("~"),
        }
        shapefile = QFileDialog.getOpenFileName(self, **options)[0]
        if shapefile == "":
            return
        self.map_plot.loadShapefile(shapefile)

    @dont_crash
    def saveShapes(self, *args, **kwargs):
        self.map_plot.saveShapes()

    @dont_crash
    def save_figure(self, *args, **kwargs):
        self.map_plot.fig.canvas.toolbar.save_figure()

    def switch_settings(self, projection):
        @dont_crash
        def switch(*args, **kwargs):
            self.map_plot.switch_settings(projection)
        return switch

    @dont_crash
    def switch_callsign(self, value, *args, **kwargs):
        self.map_plot.switch_callsign(value)

    @dont_crash
    def switch_logtab(self, value, *args, **kwargs):
        if value:
            self.tabs.addTab(self.log_tab, "Logs")
        else:
            self.tabs.removeTab(3)
