from PyQt5 import QtCore

import time
import os.path
import logging

from ..core.logging import dont_crash
from ..tasks import DataHolder, DecodeThread


class InteractiveButtons(object):

    def __init__(self, parent=None):

        logging.info('Initialize interactive buttons')
        super(InteractiveButtons, self).__init__(parent)

    @dont_crash
    def online_mode(self, *args, **kwargs):
        logging.info('Switching to online mode')
        self.timer_listen.start(3000)

        self.online_button.setEnabled(False)
        self.interactive_button.setEnabled(True)
        self.offline_button.setEnabled(True)

    @dont_crash
    def interactive_mode(self, *args, **kwargs):
        logging.info('Switching to interactive_mode')
        self.timer_listen.stop()

        self.online_button.setEnabled(True)
        self.interactive_button.setEnabled(False)
        self.offline_button.setEnabled(True)

        self.updateData()

    @dont_crash
    def offline_mode(self, *args, **kwargs):
        logging.info('Stopping decoding process')

        if self.listen_address == "127.0.0.1:30005":
            self.d1090_worker.stop()

        self.offline_button.setChecked(True)
        self.timer_listen.stop()
        self.decode.terminate()

        self.dump_button.setEnabled(True)
        try:
            self.next_button.setEnabled(True)
        except:
            pass

        self.online_button.setEnabled(False)
        self.interactive_button.setEnabled(False)
        self.offline_button.setEnabled(False)

        if self.filename != "":
            self.updateData()

    @dont_crash
    def start_dump1090(self, *args, **kwargs):

        logging.info('Starting dump1090 process')

        self.setupConnections()
        self.listen_address = "127.0.0.1:30005"
        self.listen()

    @dont_crash
    def start_next(self, *args, **kwargs):
        self.listen_address = self.config.get('listeners',
                                              self.next_listener,
                                              fallback=None)
        if self.listen_address is None:
            return
        self.listen()

    @dont_crash
    def listen(self, *args, **kwargs):
        self.dump_button.setEnabled(False)
        try:
            self.next_button.setEnabled(False)
        except Exception as e:
            logging.exception(e)
        self.online_button.setChecked(True)

        host, port = self.listen_address.split(':')

        if host == "127.0.0.1":
            time.sleep(2)
        self.filename = self.config.get('global', 'filename',
                                        fallback="~/adsb.db")
        self.filename = os.path.expanduser(self.filename)
        self.holder = DataHolder.open(self.filename)

        logging.info('Start listening on {}:{}'.format(host, port))
        self.decode = DecodeThread(host, int(port), self.filename)
        self.decode.start()

        self.timer_listen = QtCore.QTimer()
        self.timer_listen.timeout.connect(self.updatefromdict)
        self.timer_listen.start(3000)

        self.interactive_button.setEnabled(True)
        self.offline_button.setEnabled(True)
