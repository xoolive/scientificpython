from PyQt5 import QtCore

import logging

import adsb_py.adsb_decode as asd


# Subclassing QThread
# http://qt-project.org/doc/latest/qthread.html
class DecodeThread(QtCore.QThread):

    def __init__(self, *args):
        self.host, self.port, self.filename = args
        super().__init__()

    def run(self):
        try:
            asd.init_db(self.filename)
            asd.decode_loop(self.host, self.port)
        except Exception as e:
            logging.exception(e)

