import time
import logging

from PyQt5 import QtCore
from PyQt5.QtWidgets import QDateTimeEdit, QHBoxLayout, QSlider


class DateTimeSlider():

    def __init__(self, parent):

        # https://stackoverflow.com/a/16310777/1595335
        super(DateTimeSlider, self).__init__(parent)

        self.slider = QSlider(QtCore.Qt.Horizontal, self)
        self.slider.setMaximum(time.time())
        self.slider.setMinimum(time.time() - 60 * 60 * 24 * 2)
        self.slider.setValue(time.time())
        self.slider.valueChanged.connect(self.slider_changed)
        self.slider.sliderReleased.connect(self.slider_released)

        self.date_editor = QDateTimeEdit()
        self.date_editor.setDisplayFormat("MM-dd HH:mm")
        self.date_editor.setDateTime(QtCore.QDateTime.currentDateTime())
        self.date_editor.dateTimeChanged.connect(self.datetime_changed)

        self.slider_date = QHBoxLayout()
        self.slider_date.addWidget(self.slider)
        self.slider_date.addWidget(self.date_editor)

    def slider_changed(self, new_value):
        datetime = QtCore.QDateTime.fromTime_t(new_value)
        self.date_editor.blockSignals(True)
        self.date_editor.setDateTime(datetime)
        self.date_editor.blockSignals(False)
        self.datetime_slider = datetime.toPyDateTime()

    def slider_released(self):
        logging.info('Moving slider to {}'.format(self.datetime_slider))
        self.updateTable(self.datetime_slider.timestamp(),
                         self.datetime_slider.timestamp() -
                         self.config.getint('global', 'history', fallback=600),
                         update_table=True)

    def datetime_changed(self, new_datetime):
        self.slider.blockSignals(True)
        self.slider.setValue(new_datetime.toTime_t())
        self.slider.blockSignals(False)
        self.datetime_slider = new_datetime.toPyDateTime()
        logging.info('Moving datetime to {}'.format(self.datetime_slider))
        self.updateTable(self.datetime_slider.timestamp(),
                         self.datetime_slider.timestamp() -
                         self.config.getint('global', 'history', fallback=600),
                         update_table=True)
