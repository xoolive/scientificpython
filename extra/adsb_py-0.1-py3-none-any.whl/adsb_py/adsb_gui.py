from PyQt5 import QtCore

from PyQt5.QtWidgets import (QLineEdit, QPushButton,
                             QApplication, QWidget, QGridLayout,
                             QVBoxLayout, QRadioButton,
                             QTabWidget, QMainWindow, QStyle, QSystemTrayIcon)

from PyQt5 import QtGui

import sys
import os.path
import logging
import sqlite3
import configparser

import numpy as np
import pandas as pd

from datetime import datetime, timedelta

from adsb_py import adsb_decode as asd
from adsb_py import widgets as gui
from adsb_py import tasks as tsk
from adsb_py.core.logging import dont_crash, init_logging

from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT
from appdirs import user_log_dir, user_config_dir


class NavigationToolbar(NavigationToolbar2QT):
    def set_message(self, msg):
        pass


class MainScreen(gui.MenuHolder, gui.DateTimeSlider, gui.InteractiveButtons,
                 tsk.Dump1090Process, QMainWindow, ):

    def __init__(self, confdir):

        logging.info('Initialize MainScreen')
        self.config = configparser.ConfigParser()
        self.config.read(os.path.join(confdir, "kamome.conf"))

        super(MainScreen, self).__init__(parent=None)

        self.confdir = confdir
        self.sort = 'time'

        self.filename = ""
        self.setWindowTitle("kamome")
        self.setGeometry(10, 10, 920, 720)

        self.init_configuration()
        self.init_callsigns()
        self.create_widgets()
        self.set_options()
        self.set_callbacks()
        self.set_layout()

    def init_configuration(self):
        logging.info('Initialize configuration')

        if not os.path.isdir(self.confdir):
            logging.warn('Creating empty configuration directory')
            os.mkdir(self.confdir)
            os.mkdir(os.path.join(self.confdir, 'shapefiles'))

    def init_callsigns(self):

        logging.info('Initialize callsigns')

        connector = sqlite3.connect(os.path.join(self.confdir, 'metadata.db'))
        airports = pd.read_sql_query('select * from airport', connector)
        self.airports = airports[['icao', 'iata', 'city']]

        self.callsigns_db = os.path.join(self.confdir, 'callsigns.db')
        connector = sqlite3.connect(self.callsigns_db)

        try:
            self.callsigns_info = pd.read_sql_query(
                "select callsign, origin, destination, date from callsigns",
                connector)
        except pd.io.sql.DatabaseError:

            logging.warn('Initializing callsigns.db table')

            creation = """CREATE TABLE "callsigns" (
                              "callsign" TEXT,
                              "airline" TEXT,
                              "origin" TEXT,
                              "destination" TEXT,
                              "date" DATE,
                              primary key ("callsign", "date")
                            );"""
            connector.execute(creation)
            connector.commit()
            e = {'callsign': [], 'origin': [], 'destination': [],
                 'date': []}
            self.callsigns_info = pd.DataFrame(e)

        self.callsigns_info = (
            self.callsigns_info
            .merge(self.airports.rename(columns={'city': 'o_city'}),
                   left_on="origin", right_on='icao', how='left')
            .merge(self.airports.rename(columns={'city': 'd_city'}),
                   left_on="destination", right_on='icao', how='left')
            .assign(
                date=self.callsigns_info.date.apply(
                    lambda x: datetime.strptime(x, "%Y-%m-%d")
                    if isinstance(x, str) else np.datetime64('NaT')),
            ))

    # -- Widgets --
    def create_widgets(self):

        logging.info('Creating widgets')

        self.dump_button = QPushButton("dump1090")
        openIcon = self.style().standardIcon(QStyle.SP_DialogOpenButton)
        self.file_button = QPushButton(openIcon, 'Open file', self)

        try:
            self.next_listener = next(iter(self.config["listeners"]))
            self.next_button = QPushButton(self.next_listener)
        except Exception as e:
            logging.info("No listeners found")

        self.online_button = QRadioButton("online")
        self.online_button.setEnabled(False)
        self.interactive_button = QRadioButton("interactive")
        self.interactive_button.setEnabled(False)
        self.offline_button = QRadioButton("offline")
        self.offline_button.setEnabled(False)
        self.offline_button.setChecked(True)

    # -- Options --
    def set_options(self):

        logging.info('Setting options')

        icon_grey = QtGui.QIcon(
            os.path.join(os.path.dirname(__file__), 'data',
                         'travel-grey.svg'))
        self.setWindowIcon(icon_grey)

        icon_color = icon_grey
        if sys.platform == "linux":
            icon_color = QtGui.QIcon(
                os.path.join(os.path.dirname(__file__), 'data',
                             'travel-mini-white.svg'))
        if sys.platform == "darwin":
            icon_color = QtGui.QIcon(
                os.path.join(os.path.dirname(__file__), 'data',
                             'travel-mini-grey.svg'))

        self.trayIcon = QSystemTrayIcon(icon_color, self)
        self.trayIcon.show()

        self.dump_button.setMaximumWidth(150)
        self.file_button.setFlat(True)

    # -- Callbacks --
    def set_callbacks(self):

        logging.info('Setting callbacks')

        self.file_button.clicked.connect(self.openFile)
        self.dump_button.clicked.connect(self.start_dump1090)
        try:
            self.next_button.clicked.connect(self.start_next)
        except Exception as e:
            logging.info("No listeners found")
        self.online_button.clicked.connect(self.online_mode)
        self.interactive_button.clicked.connect(self.interactive_mode)
        self.offline_button.clicked.connect(self.offline_mode)

    # -- Layout --
    def set_layout(self):

        logging.info('Setting layout')

        buttonPart = QGridLayout()
        buttonPart.addWidget(self.file_button, 0, 0, QtCore.Qt.AlignCenter)
        buttonPart.addWidget(self.online_button, 0, 1)
        buttonPart.addWidget(self.interactive_button, 0, 2)
        buttonPart.addWidget(self.offline_button, 0, 3)
        buttonPart.addWidget(self.dump_button, 1, 1, QtCore.Qt.AlignCenter)

        try:
            buttonPart.addWidget(self.next_button, 1, 2, QtCore.Qt.AlignCenter)
        except Exception as e:
            logging.info("No listeners found")

        # -- Plot layout --

        left_part = QVBoxLayout()
        left_part.addLayout(buttonPart)

        self.tabs = QTabWidget()
        map_tab = QWidget()
        map_layout = QVBoxLayout()
        map_tab.setLayout(map_layout)

        self.map_plot = gui.MapCanvas(parent=self, config=self.config,
                                      width=5, height=4)
        self.map_plot.move(0, 0)

        map_toolbar = NavigationToolbar2QT(self.map_plot, map_tab)
        map_toolbar.setVisible(False)
        map_layout.addWidget(map_toolbar)
        map_layout.addWidget(self.map_plot)
        map_toolbar.pan()

        self.detail_plot = gui.DetailCanvas(self, width=5, height=4)
        self.detail_plot.move(0, 0)

        detail_tab = QWidget()
        detail_layout = QVBoxLayout()
        detail_tab.setLayout(detail_layout)
        detail_toolbar = NavigationToolbar(self.detail_plot, detail_tab)
        detail_layout.addWidget(detail_toolbar)
        detail_layout.addWidget(self.detail_plot)

        d1090_tab = QWidget()
        d1090_layout = QVBoxLayout()
        d1090_tab.setLayout(d1090_layout)
        d1090_layout.addWidget(self.d1090_output)

        self.handler = gui.LoggingHandler()
        self.log_tab = QWidget()
        log_layout = QVBoxLayout()
        self.log_tab.setLayout(log_layout)
        log_layout.addWidget(self.handler.log_output)

        self.tabs.addTab(map_tab, "Map")
#         self.tabs.addTab(detail_tab, "Details")
        self.tabs.addTab(d1090_tab, "dump1090")
#         self.tabs.addTab(self.log_tab, "Logs")

        left_part.addWidget(self.tabs)

        self.queryLine = QLineEdit()
#         self.queryLine.returnPressed.connect(self.queryCallsign)

        self.tableView = gui.MyTableView(self)

#         self.info = tsk.FlightInfoThread(self)

        right_part = QVBoxLayout()
        right_part.addWidget(self.queryLine)
        right_part.addLayout(self.slider_date)
        right_part.addWidget(self.tableView)
        self.tableView.clicked.connect(self.line_clicked)
        self.tableView.verticalHeader().sectionClicked.connect(
            self.line_clicked)
        self.tableView.horizontalHeader().sectionClicked.connect(
            self.column_clicked)

        mainLayout = QGridLayout()
        mainLayout.addLayout(left_part, 0, 0)
        mainLayout.addLayout(right_part, 0, 1)

        mainWidget = QWidget()
        mainWidget.setLayout(mainLayout)
        self.setCentralWidget(mainWidget)

    @dont_crash
    def column_clicked(self, args):
        self.sort = self.tableView.model()._df.columns.tolist()[args]
        self.tableView.model().sort(args, QtCore.Qt.AscendingOrder)

    @dont_crash
    def line_clicked(self, *args, **kwargs):
        selected = set(ix.row() for ix in self.tableView.selectedIndexes())
        callsigns = list(self.tableView.model()._df.index.tolist()[ix]
                         for ix in selected)
        logging.debug("Selected callsigns: {}".format(callsigns))
        self.updateTable(self.datetime_slider.timestamp(),
                         self.datetime_slider.timestamp() -
                         self.config.getint('global', 'history', fallback=600),
                         callsigns)

    @dont_crash
    def updatefromdict(self, *args, **kwargs):

#         with asd.aircraft_lock:
        all_data = [(icao24, ac.first, ac.last, ac.cs, ac.alt, *ac.pos)
                    for icao24, ac in asd.AIRCRAFT.items()
                    if ac.last > (datetime.now() -
                                  timedelta(minutes=2)).timestamp()]
        if len(all_data) == 0:
            return

        icao24, first, last, cs, alt, lat, lon = list(zip(*all_data))
        data = (pd.DataFrame(
            {'first': first,
             'icao': icao24,
             'last': last,
             'callsign': cs,
             'alt': alt,
             'lat': lat,
             'lon': lon}).assign(
                 time=lambda df: df['last'].astype(float).
                 apply(datetime.fromtimestamp),
                 start=lambda df: df['first'].astype(float).
                 apply(datetime.fromtimestamp), ))
        data = data[data.lat.notnull()]
        if data.shape[0] == 0:
            return

        self.tableView.setModel(gui.PandasModel(data, self.callsigns_info,
                                                sort=self.sort))

        if self.map_plot.axes is not None:
            self.map_plot.lims = self.map_plot.axes.axis()

        self.map_plot.plot(data)

#         if not self.info.isRunning():
#             self.info.start()

    @dont_crash
    def updateData(self, *args, **kwargs):

        min_time, max_time = self.holder.get_min_max()
        logging.info("Data between {} ({}) and {} ({})".format(
            min_time, datetime.fromtimestamp(min_time),
            max_time, datetime.fromtimestamp(max_time)))

        self.slider.setMaximum(max_time)
        self.slider.setMinimum(min_time)
        self.slider.setValue(max_time)
        self.slider_changed(max_time)

        self.updateTable(max_time, max_time -
                         self.config.getint('global', 'history', fallback=600),
                         update_table=True)

    @dont_crash
    def updateTable(self, time_up, time_low, flights=[],
                    update_table=False, *args, **kwargs):

        logging.info('Updating callsign table')
        logging.debug("Flights: {}".format(flights))

        data = self.holder.get_data(time_up, time_low, flights)

        def select(data):
            callsign = data.callsign.values[0]
            if callsign in flights:
                return data.sort_values('time', ascending=True)
            else:
                return data[data.lat.notnull()].sort_values(
                    'time', ascending=False).head(1)

        data = (data.groupby('callsign').apply(select))

        self.map_plot.plot(data)
        self.detail_plot.plot(data)

        if update_table:
            self.tableView.setModel(gui.PandasModel(data, self.callsigns_info,
                                                    sort=self.sort))

#         if not self.info.isRunning():
#             self.info.start()

def main():

    if sys.platform == 'win32':
        # This lets you keep your custom icon in the Windows taskbar
        import ctypes
        myappid = 'org.xoolive.kamome'
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)

    confdir = user_config_dir('kamome')
    logdir = user_log_dir('kamome')

    if not os.path.isdir(confdir):
        import adsb_py.core.initialize as init
        os.makedirs(confdir)
        init.init_config(os.path.join(confdir, 'kamome.conf'))
        init.init_airports(os.path.join(confdir, 'metadata.db'))
        os.makedirs(os.path.join(confdir, 'shapefiles'))

    if not os.path.isdir(logdir):
        os.makedirs(logdir)

    init_logging(logdir)

    logging.info('Configuration directory: {}'.format(confdir))
    logging.info('Logging directory: {}'.format(logdir))

    app = QApplication(sys.argv)
    main = MainScreen(confdir)
    main.show()
    return app.exec_()


if __name__ == '__main__':
    main()
