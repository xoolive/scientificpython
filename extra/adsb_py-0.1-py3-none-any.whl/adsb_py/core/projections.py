import cartopy.crs as ccrs
from shapely import geometry


class Lambert93(ccrs.LambertConformal):
    """
    Lambert Conformal projection for France (IGN).
    Ellipsoid is WGS84.
    """
    def __init__(self):
        globe = ccrs.Globe(ellipse='GRS80')
        super(Lambert93, self).__init__(3, 46.5,
                                        standard_parallels=(44, 49),
                                        false_easting=700000,
                                        false_northing=6600000,
                                        globe=globe)

    @property
    def x_limits(self):
        return (0, 1300000)

    @property
    def y_limits(self):
        return (5900000, 7200000)

    @property
    def boundary(self):
        x0, x1 = self.x_limits
        y0, y1 = self.y_limits
        return geometry.LineString([(x0, y0), (x0, y1),
                                    (x1, y1), (x1, y0), (x0, y0)])


class UTM52(ccrs.UTM):
    """
    UTM Zone 52 projection for North-East Asia (CJK zone).
    Ellipsoid is International 1924.
    """
    def __init__(self):
        globe = ccrs.Globe(ellipse='intl')
        zone = 52
        super(UTM52, self).__init__(zone, globe=globe)

    @property
    def x_limits(self):
        return (-1.4e6, 2.1e6)

    @property
    def y_limits(self):
        return (2.35e6, 6e6)


class Amersfoort(ccrs.Stereographic):
    """
    Amersfoort projection for the Netherlands.
    Ellipsoid is Bessel 1841.
    https://epsg.io/28992
    """
    def __init__(self):
        globe = ccrs.Globe(ellipse='bessel')
        super(Amersfoort, self).__init__(52.15616055555555,
                                         5.38763888888889,
                                         false_easting=155000,
                                         false_northing=463000,
                                         true_scale_latitude=0.9999079,
                                         globe=globe)

    @property
    def x_limits(self):
        return (-100000, 330000)

    @property
    def y_limits(self):
        return (150000, 650000)

    @property
    def boundary(self):
        x0, x1 = self.x_limits
        y0, y1 = self.y_limits
        return geometry.LineString([(x0, y0), (x0, y1),
                                    (x1, y1), (x1, y0), (x0, y0)])


class GaussKruger(ccrs.TransverseMercator):
    """
    Gauss-Kruger projection for Germany.
    Ellipsoid is Bessel 1841.
    https://epsg.io/5680-15949
    """
    def __init__(self):
        globe = ccrs.Globe(ellipse='bessel')
        super(GaussKruger, self).__init__(3, 0, scale_factor=1,
                                          false_easting=1500000,
                                          false_northing=0,
                                          globe=globe)

    @property
    def x_limits(self):
        return (1600000, 2400000)

    @property
    def y_limits(self):
        return (5200000, 6200000)

    @property
    def boundary(self):
        x0, x1 = self.x_limits
        y0, y1 = self.y_limits
        return geometry.LineString([(x0, y0), (x0, y1),
                                    (x1, y1), (x1, y0), (x0, y0)])



projections = {
    'EuroPP': ccrs.EuroPP(),
    'Lambert 93': Lambert93(),
    'Orthographic': ccrs.Orthographic(75.0, 30.0),
    'Robinson': ccrs.Robinson(),
    'UTM 52': UTM52(),
    'Amersfoort': Amersfoort(),
    'Gauss Kruger': GaussKruger()
}
