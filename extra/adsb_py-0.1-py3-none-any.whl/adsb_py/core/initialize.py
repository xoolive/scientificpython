import requests
import sqlite3
from io import StringIO

import pandas as pd


__basic_config = """
[global]
logs = yes
filename = ~/adsb.db

[maps]
settings = Ile de France, Europe

[default]
projection = Lambert 93

[Ile de France]
projection = Lambert 93
shortcut = Ctrl+P
admin-unit = United Kingdom, Belgium
admin-more = France, Germany
lims = 5.75484e+05, 7.43739e+05, 6.77037e+06, 6.93297e+06
precision = 10m
rivers = yes
airports = LFPO, LFPG

[Europe]
projection = EuroPP
shortcut = Ctrl+E
admin = France, Spain, Italy
admin-more = Germany, Netherlands, Austria, Switzerland, Denmark, Sweden
admin-unit = United Kingdom, Belgium
lims = -6.21646e+05, 8.27307e+05, 4.59085e+06, 6.25288e+06
precision = 50m
airports = LFPG, LFPO
"""


def init_config(filename):
    with open(filename, 'w') as fh:
        fh.write(__basic_config)


def init_airports(filename):
    url = "https://raw.githubusercontent.com/jpatokal/openflights/master/data/airports.dat"

    r = requests.get(url)
    s = StringIO(r.content.decode())
    table = pd.read_csv(s, header=-1).iloc[:, range(1, 9)]
    table.columns = ['airport', 'city', 'country', 'iata', 'icao',
                     'lat', 'lon', 'alt']
    connector = sqlite3.connect(filename)
    table.to_sql('airport', connector)

