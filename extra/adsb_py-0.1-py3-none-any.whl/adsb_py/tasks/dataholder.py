import os.path
import sqlite3
import logging
import pandas as pd

from datetime import datetime


class DataHolder(object):

    def __init__(self, filename):
        self.filename = filename

    @classmethod
    def open(self, filename):
        logging.info('Opening file {}'.format(filename))
        _, ext = os.path.splitext(filename)
        logging.debug('Extension: {}'.format(ext))
        if ext == '.db':
            return Sqlite3Holder(filename)
        if ext == '.pkl':
            return PickleHolder(filename)
        raise NotImplemented

    def get_min_max(self):
        raise NotImplemented

    def get_data(time_up, time_low, flights=[]):
        raise NotImplemented


class Sqlite3Holder(DataHolder):

    def get_min_max(self):

        self.c = sqlite3.connect("file:{}?mode=ro".format(self.filename),
                                 uri=True)

        max_time_query = "SELECT max(timestamp) FROM positions"
        max_time = pd.read_sql_query(max_time_query, self.c).values[0][0]
        min_time_query = "SELECT min(timestamp) FROM positions"
        min_time = pd.read_sql_query(min_time_query, self.c).values[0][0]

        return min_time, max_time

    def get_data(self, time_up, time_low, flights=[]):

        self.c = sqlite3.connect("file:{}?mode=ro".format(self.filename),
                                 uri=True)

        pos_req = """SELECT *, (SELECT callsign FROM callsigns
                                WHERE positions.icao = callsigns.icao
                                AND timestamp <= lastseen + 60
                                AND timestamp >= start - 60) AS callsign
                     FROM positions
                     WHERE timestamp >= {} AND timestamp <= {}"""

        srf_req = """SELECT *, (SELECT callsign FROM callsigns
                                WHERE surface.icao = callsigns.icao
                                AND timestamp <= lastseen + 60
                                AND timestamp >= start - 60) AS callsign
                     FROM surface
                     WHERE timestamp >= {} AND timestamp <= {}"""

        pos_req = """SELECT *
                     FROM positions
                     WHERE timestamp >= {} AND timestamp <= {}"""

        srf_req = """SELECT *
                     FROM surface
                     WHERE timestamp >= {} AND timestamp <= {}"""

        data = pd.read_sql_query(pos_req.format(time_low, time_up), self.c)
        surf = pd.read_sql_query(srf_req.format(time_low, time_up), self.c)
        data = pd.concat([data, surf])
        data = data.assign(time=lambda df: df.timestamp.
                           astype(float).apply(datetime.fromtimestamp))

        if data.shape[0] == 0:
            return

        def get_data(callsign):
            request = """SELECT *, (SELECT callsign FROM callsigns
                                    WHERE {table}.icao = callsigns.icao
                                    AND timestamp <= lastseen + 60
                                    AND timestamp >= start - 60) AS callsign
                         FROM {table} WHERE timestamp >= {start}
                         AND timestamp <= {lastseen}
                         AND callsign = '{callsign}'"""
            request = """SELECT *
                         FROM {table} WHERE timestamp >= {start}
                         AND timestamp <= {lastseen}
                         AND callsign = '{callsign}'"""
            table = pd.concat([pd.read_sql_query(request.format(
                callsign=callsign, lastseen=time_up, table=table,
                start=time_up - 15 * 60 * 60  # 15 hours?
            ), self.c)
                for table in ['positions', 'surface', 'speed', 'tracks']])
            return table.assign(time=lambda df: df.timestamp.
                                astype(float).apply(datetime.fromtimestamp)
                                ).sort_values('time')

        full = [get_data(callsign) for callsign in flights]
        full.append(data)

        return pd.concat(full)


class PickleHolder(DataHolder):

    def __init__(self, filename):
        self.data = pd.read_pickle(filename)
        self.data = self.data.assign(
            alt=(3.28084 * self.data.geoaltitude).round(),
            icao=self.data.icao24.apply(lambda x: int("0x{}".format(x), 16)))
        self.data.loc[self.data.lat.notnull() & self.data.onground,
                      ['alt']] = None

    def get_min_max(self):
        return (self.data.time.min().timestamp(),
                self.data.time.max().timestamp())

    def get_data(self, time_up, time_low, flights=[]):
        max_ = datetime.fromtimestamp(time_up)
        min_ = datetime.fromtimestamp(time_low)
        return self.data[(self.data.time <= max_) &
                         (self.data.time >= min_)]
