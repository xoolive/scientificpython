import datetime as dt

airports = {
    'LFBO': {'latmin': 43.59, 'latmax': 43.68, 'lonmin': 1.3, 'lonmax': 1.43},
    'LFPG': {'latmin': 48.51 ,'latmax': 49.50, 'lonmin': 2.5, 'lonmax': 2.7},
}

request = """
select callsign, s.ITEM as serial, count(*) as count, hour
from state_vectors_data4, state_vectors_data4.serials s
where hour>={hourmin} and hour<={hourmax}
and lat>={latmin} and lat<={latmax} and lon>={lonmin} and lon<={lonmax} and
baroaltitude<300 group by icao24, callsign, s.ITEM, hour;
"""


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="Build OpenSky request")

    parser.add_argument(
        "icao", help="ICAO identifiers for given airport")

    parser.add_argument(
        "start", help="Start date (e.g. 20170101)")

    parser.add_argument(
        "stop", help="End date (e.g. 20170101)")

    args = parser.parse_args()

    hourmin = dt.datetime.strptime(args.start, "%Y%m%d").timestamp()
    hourmax = dt.datetime.strptime(args.stop, "%Y%m%d").timestamp()

    print(request.format(hourmin=hourmin, hourmax=hourmax,
                         **airports[args.icao]))

