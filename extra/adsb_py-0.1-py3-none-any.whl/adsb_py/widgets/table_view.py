from PyQt5.QtWidgets import QMenu, QTableView, QAction
from PyQt5 import QtCore

from adsb_py.core.logging import dont_crash
from adsb_py import tasks as tsk


class MyTableView(QTableView):

    def __init__(self, parent=None):

        super(MyTableView, self).__init__()

        self.verticalHeader().setContextMenuPolicy(
            QtCore.Qt.CustomContextMenu)
#         self.verticalHeader().customContextMenuRequested.connect(self.get_menu)

        self.setSortingEnabled(True)
#         self.flight_info = tsk.flight_info.FlightInfo(parent)

    @dont_crash
    def get_menu(self, pos, *args, **kwargs):
        index = self.indexAt(pos)
        menu = QMenu()
        txt = "Get information for flight {}"
        callsign = self.model()._df.index.tolist()[index.row()]
        information = QAction(txt.format(callsign), menu,
                              triggered=lambda: self.get_info(callsign))
        menu.addAction(information)
        menu.exec_(self.mapToGlobal(pos))

    @dont_crash
    def get_info(self, callsign, *args, **kwargs):
        self.flight_info.get_info_update(
            self.flight_info.get_info_fallback, callsign)

        if self.flight_info.results == 5:
            self.flight_info.update_db()


class PandasModel(QtCore.QAbstractTableModel):

    def __init__(self, data, callsigns_info, sort='time', parent=None):
        QtCore.QAbstractTableModel.__init__(self, parent=parent)

        self._df = (data.groupby('callsign').
                    apply(lambda df:
                          df.sort_values('time', ascending=False).head(1)).
                    set_index('callsign')[['icao', 'time', 'alt']].
                    merge(callsigns_info,
                          right_on='callsign',
                          how='left',
                          left_index=True))

        self._df = (self._df.assign(delta=self._df.time - self._df.date)
                    .groupby('callsign')
                    .apply(lambda x: x.sort_values('delta').head(1))
                    .set_index("callsign")
                    )

        self._df['time'] = self._df.time.apply(
            lambda x: x.time().strftime("%H:%M:%S"))
        self._df['icao'] = self._df.icao.apply(
            lambda x: "0x{:x}".format(int(x)))
        self._df = self._df[['icao', 'time', 'alt',]]
#                              'origin', 'o_city', 'destination', 'd_city']]
        self._df = self._df.sort_values(sort)

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role != QtCore.Qt.DisplayRole:
            return QtCore.QVariant()

        if orientation == QtCore.Qt.Horizontal:
            try:
                return self._df.columns.tolist()[section]
            except (IndexError, ):
                return QtCore.QVariant()
        elif orientation == QtCore.Qt.Vertical:
            try:
                # return self.df.index.tolist()
                return self._df.index.tolist()[section]
            except (IndexError, ):
                return QtCore.QVariant()

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if role != QtCore.Qt.DisplayRole:
            return QtCore.QVariant()

        if not index.isValid():
            return QtCore.QVariant()

        return QtCore.QVariant(str(self._df.ix[index.row(), index.column()]))

    def setData(self, index, value, role):
        row = self._df.index[index.row()]
        col = self._df.columns[index.column()]
        if hasattr(value, 'toPyObject'):
            # PyQt4 gets a QVariant
            value = value.toPyObject()
        else:
            # PySide gets an unicode
            dtype = self._df[col].dtype
            if dtype != object:
                value = None if value == '' else dtype.type(value)
        self._df.set_value(row, col, value)
        return True

    def updateLine(self, row, col, value):
        self.layoutAboutToBeChanged.emit()
        self._df.set_value(row, col, value)
        self.layoutChanged.emit()

    def rowCount(self, parent=QtCore.QModelIndex()):
        return len(self._df.index)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return len(self._df.columns)

    def sort(self, column, order):
        colname = self._df.columns.tolist()[column]
        self.layoutAboutToBeChanged.emit()
        self._df.sort_values(colname,
                             ascending=(order == QtCore.Qt.AscendingOrder),
                             inplace=True)
        self.layoutChanged.emit()
