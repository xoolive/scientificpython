from PyQt5.QtWidgets import QTextEdit

import logging


class LoggingHandler(logging.Handler):

    def __init__(self):
        super(LoggingHandler, self).__init__()
        self.log_output = QTextEdit()
        self.log_output.setMaximumHeight(400)
        self.setLevel(logging.WARNING)
        fmt = logging.Formatter('%(asctime)s - %(levelname)-8s %(message)s')
        self.setFormatter(fmt)
        logging.getLogger('').addHandler(self)

    def emit(self, record):
        msg = self.format(record)
        self.log_output.append(msg)
