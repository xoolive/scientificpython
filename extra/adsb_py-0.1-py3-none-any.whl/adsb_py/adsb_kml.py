# coding: utf-8

import os.path
from datetime import datetime

import pandas as pd
import simplekml

from adsb_py import adsb_query as ask
from geotools.projection import sph2lcc
from geotools.simplification import douglas_peucker

AIRCRAFT = "http://maps.google.com/mapfiles/kml/shapes/airports.png"


def getdata(filename):
    spl = os.path.splitext(filename)
    if len(filename) < 2:
        raise Exception("Cannot guess file type")
    if spl[1] == ".pkl":
        return pd.read_pickle(filename)
    if spl[1] == ".db":
        import sqlite3
        connect = sqlite3.connect(filename)
        request = """select * from positions left join callsigns
                     on positions.icao = callsigns.icao;"""
        data = pd.read_sql(request, connect)
        data['time'] = data.timestamp.apply(datetime.utcfromtimestamp)
        data = data[data.timestamp <= data.lastseen]
        data = data[data.timestamp >= data.start]
        data.rename_axis({'alt': 'geoaltitude'}, axis="columns", inplace=True)
        return data
    raise Exception("Cannot guess file type")


def export(filename, output, start=None, stop=None, compress=False):

    kml = simplekml.Kml(name="ADS-B Traffic")
    folder = kml.newfolder(name="Callsigns")

    style = simplekml.StyleMap()
    style.normalstyle.iconstyle.icon.href = AIRCRAFT
    style.normalstyle.iconstyle.scale = 0.5
    style.highlightstyle.iconstyle.icon.href = AIRCRAFT
    style.highlightstyle.iconstyle.scale = 1.0
    style.normalstyle.labelstyle.scale = 0.5
    style.highlightstyle.labelstyle.scale = 1.0
    style.highlightstyle.labelstyle.color = simplekml.Color.yellow

    def data2kml(data):
        nonlocal folder, start, stop

        data = data.sort_values('time')
        data = data[(data.time >= start) & (data.time <= stop)]
        if data.shape[0] < 5: return

        if compress:
            mask = douglas_peucker(*sph2lcc(lat=data.lat, lon=data.lon),
                                   1e3, True)
            data = data[mask]

        trk = folder.newgxtrack(name=data.callsign.values[0])
        fmt = "%Y-%m-%dT%H:%M:%S.%fZ"
        trk.newwhen(list(data['time'].apply(lambda t: t.strftime(fmt))))
        trk.newgxcoord(list(zip(data.lon, data.lat, data.geoaltitude)))
        trk.stylemap = style

        desc = """<i>{airline}</i><br/>""".format(
            airline=next(ask.airline_query(data.callsign.values[0][:3]), ""))
        info = next(ask.callsign_query(data.callsign.values[0]), None)
        if info is not None:
            desc += """<b>{tkf}</b>: {takeoff}<br/> →
                       <b>{lnd}</b>: {landing}<br/>"""
            from_ = next(ask.airport_query(info.provenance), None)
            from_ = from_.city if from_ is not None else "???"
            dest_ = next(ask.airport_query(info.destination), None)
            dest_ = dest_.city if dest_ is not None else "???"
            desc = desc.format(tkf=info.provenance, takeoff=from_,
                               lnd=info.destination, landing=dest_)
        trk.description = desc

    data = getdata(filename)

    if start is not None:
        start = datetime.strptime(start, "%Y-%m-%d/%H:%M")
    else:
        start = data.time.min()

    if stop is not None:
        stop = datetime.strptime(stop, "%Y-%m-%d/%H:%M")
    else:
        stop = data.time.max()

    data.groupby('callsign').apply(data2kml)

    kml.save(output)
    print("{} written.".format(output))


if __name__ == '__main__':

    import argparse

    parser = argparse.ArgumentParser(description="Replay traffic in a KML")

    parser.add_argument(
        "filename", help="Pickle file containing data")

    parser.add_argument(
        "start", help="Start date/time (e.g. 2017-01-01/20:00)",
        nargs="?")

    parser.add_argument(
        "stop", help="End date/time (e.g. 2017-01-01/20:00)",
        nargs="?")

    parser.add_argument(
        "-o", "--output", action="store_true",
        help="Output KML file, default: traffic.kml",
        default="traffic.kml")

    parser.add_argument(
        "-c", "--compress", action="store_true",
        help="Compress trajectories with Douglas-Peucker algorithm",
        default=False)

    args = parser.parse_args()

    export(args.filename, start=args.start, stop=args.stop,
           output=args.output, compress=args.compress)

