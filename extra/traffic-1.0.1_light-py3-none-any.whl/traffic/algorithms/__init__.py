# flake8: noqa
from .douglas_peucker import douglas_peucker
